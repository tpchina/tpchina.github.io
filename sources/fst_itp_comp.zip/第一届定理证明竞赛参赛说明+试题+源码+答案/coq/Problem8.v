From Coq Require Import String List ZArith.
From compcert Require Import Coqlib Integers Floats AST Ctypes Cop Clight Clightdefs.
Import Clightdefs.ClightNotations.
Local Open Scope Z_scope.
Local Open Scope string_scope.
Local Open Scope clight_scope.

Module Info.
  Definition version := "3.16".
  Definition build_number := "".
  Definition build_tag := "".
  Definition build_branch := "".
  Definition arch := "x86".
  Definition model := "64".
  Definition abi := "standard".
  Definition bitsize := 64.
  Definition big_endian := false.
  Definition source_file := "/mnt/c/Users/mooc3/Downloads/mem_alloc.c".
  Definition normalized := false.
End Info.

Definition ___builtin_ais_annot : ident := $"__builtin_ais_annot".
Definition ___builtin_annot : ident := $"__builtin_annot".
Definition ___builtin_annot_intval : ident := $"__builtin_annot_intval".
Definition ___builtin_bswap : ident := $"__builtin_bswap".
Definition ___builtin_bswap16 : ident := $"__builtin_bswap16".
Definition ___builtin_bswap32 : ident := $"__builtin_bswap32".
Definition ___builtin_bswap64 : ident := $"__builtin_bswap64".
Definition ___builtin_clz : ident := $"__builtin_clz".
Definition ___builtin_clzl : ident := $"__builtin_clzl".
Definition ___builtin_clzll : ident := $"__builtin_clzll".
Definition ___builtin_ctz : ident := $"__builtin_ctz".
Definition ___builtin_ctzl : ident := $"__builtin_ctzl".
Definition ___builtin_ctzll : ident := $"__builtin_ctzll".
Definition ___builtin_debug : ident := $"__builtin_debug".
Definition ___builtin_expect : ident := $"__builtin_expect".
Definition ___builtin_fabs : ident := $"__builtin_fabs".
Definition ___builtin_fabsf : ident := $"__builtin_fabsf".
Definition ___builtin_fmadd : ident := $"__builtin_fmadd".
Definition ___builtin_fmax : ident := $"__builtin_fmax".
Definition ___builtin_fmin : ident := $"__builtin_fmin".
Definition ___builtin_fmsub : ident := $"__builtin_fmsub".
Definition ___builtin_fnmadd : ident := $"__builtin_fnmadd".
Definition ___builtin_fnmsub : ident := $"__builtin_fnmsub".
Definition ___builtin_fsqrt : ident := $"__builtin_fsqrt".
Definition ___builtin_membar : ident := $"__builtin_membar".
Definition ___builtin_memcpy_aligned : ident := $"__builtin_memcpy_aligned".
Definition ___builtin_read16_reversed : ident := $"__builtin_read16_reversed".
Definition ___builtin_read32_reversed : ident := $"__builtin_read32_reversed".
Definition ___builtin_sel : ident := $"__builtin_sel".
Definition ___builtin_sqrt : ident := $"__builtin_sqrt".
Definition ___builtin_unreachable : ident := $"__builtin_unreachable".
Definition ___builtin_va_arg : ident := $"__builtin_va_arg".
Definition ___builtin_va_copy : ident := $"__builtin_va_copy".
Definition ___builtin_va_end : ident := $"__builtin_va_end".
Definition ___builtin_va_start : ident := $"__builtin_va_start".
Definition ___builtin_write16_reversed : ident := $"__builtin_write16_reversed".
Definition ___builtin_write32_reversed : ident := $"__builtin_write32_reversed".
Definition ___compcert_i64_dtos : ident := $"__compcert_i64_dtos".
Definition ___compcert_i64_dtou : ident := $"__compcert_i64_dtou".
Definition ___compcert_i64_sar : ident := $"__compcert_i64_sar".
Definition ___compcert_i64_sdiv : ident := $"__compcert_i64_sdiv".
Definition ___compcert_i64_shl : ident := $"__compcert_i64_shl".
Definition ___compcert_i64_shr : ident := $"__compcert_i64_shr".
Definition ___compcert_i64_smod : ident := $"__compcert_i64_smod".
Definition ___compcert_i64_smulh : ident := $"__compcert_i64_smulh".
Definition ___compcert_i64_stod : ident := $"__compcert_i64_stod".
Definition ___compcert_i64_stof : ident := $"__compcert_i64_stof".
Definition ___compcert_i64_udiv : ident := $"__compcert_i64_udiv".
Definition ___compcert_i64_umod : ident := $"__compcert_i64_umod".
Definition ___compcert_i64_umulh : ident := $"__compcert_i64_umulh".
Definition ___compcert_i64_utod : ident := $"__compcert_i64_utod".
Definition ___compcert_i64_utof : ident := $"__compcert_i64_utof".
Definition ___compcert_va_composite : ident := $"__compcert_va_composite".
Definition ___compcert_va_float64 : ident := $"__compcert_va_float64".
Definition ___compcert_va_int32 : ident := $"__compcert_va_int32".
Definition ___compcert_va_int64 : ident := $"__compcert_va_int64".
Definition _block_size : ident := $"block_size".
Definition _free_list : ident := $"free_list".
Definition _l : ident := $"l".
Definition _list : ident := $"list".
Definition _main : ident := $"main".
Definition _mem : ident := $"mem".
Definition _mem_alloc : ident := $"mem_alloc".
Definition _next : ident := $"next".
Definition _nl : ident := $"nl".
Definition _size : ident := $"size".
Definition _sz : ident := $"sz".

Definition f_mem_alloc := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_free_list, (tptr (tptr (Tstruct _list noattr)))) ::
                (_mem, (tptr (tptr (Tstruct _list noattr)))) ::
                (_size, tint) :: nil);
  fn_vars := nil;
  fn_temps := ((_l, (tptr (Tstruct _list noattr))) :: (_sz, tint) ::
               (_nl, (tptr (Tstruct _list noattr))) :: nil);
  fn_body :=
(Ssequence
  (Sset _l
    (Ederef (Etempvar _free_list (tptr (tptr (Tstruct _list noattr))))
      (tptr (Tstruct _list noattr))))
  (Ssequence
    (Sifthenelse (Ebinop Oeq (Etempvar _l (tptr (Tstruct _list noattr)))
                   (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid)) tint)
      (Ssequence
        (Sassign
          (Ederef (Etempvar _mem (tptr (tptr (Tstruct _list noattr))))
            (tptr (Tstruct _list noattr)))
          (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid)))
        (Sreturn (Some (Econst_int (Int.repr 0) tint))))
      Sskip)
    (Ssequence
      (Sset _sz
        (Efield
          (Ederef (Etempvar _l (tptr (Tstruct _list noattr)))
            (Tstruct _list noattr)) _block_size tint))
      (Ssequence
        (Sifthenelse (Ebinop Oge (Etempvar _sz tint) (Etempvar _size tint)
                       tint)
          (Ssequence
            (Sassign
              (Ederef (Etempvar _mem (tptr (tptr (Tstruct _list noattr))))
                (tptr (Tstruct _list noattr)))
              (Etempvar _l (tptr (Tstruct _list noattr))))
            (Ssequence
              (Sset _l
                (Efield
                  (Ederef (Etempvar _l (tptr (Tstruct _list noattr)))
                    (Tstruct _list noattr)) _next
                  (tptr (Tstruct _list noattr))))
              (Ssequence
                (Sassign
                  (Ederef
                    (Etempvar _free_list (tptr (tptr (Tstruct _list noattr))))
                    (tptr (Tstruct _list noattr)))
                  (Etempvar _l (tptr (Tstruct _list noattr))))
                (Sreturn (Some (Econst_int (Int.repr 1) tint))))))
          Sskip)
        (Ssequence
          (Sset _nl
            (Efield
              (Ederef (Etempvar _l (tptr (Tstruct _list noattr)))
                (Tstruct _list noattr)) _next (tptr (Tstruct _list noattr))))
          (Ssequence
            (Swhile
              (Ebinop One (Etempvar _nl (tptr (Tstruct _list noattr)))
                (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid)) tint)
              (Ssequence
                (Sset _sz
                  (Efield
                    (Ederef (Etempvar _nl (tptr (Tstruct _list noattr)))
                      (Tstruct _list noattr)) _block_size tint))
                (Ssequence
                  (Sifthenelse (Ebinop Oge (Etempvar _sz tint)
                                 (Etempvar _size tint) tint)
                    (Ssequence
                      (Sassign
                        (Ederef
                          (Etempvar _mem (tptr (tptr (Tstruct _list noattr))))
                          (tptr (Tstruct _list noattr)))
                        (Etempvar _nl (tptr (Tstruct _list noattr))))
                      (Ssequence
                        (Sset _nl
                          (Efield
                            (Ederef
                              (Etempvar _nl (tptr (Tstruct _list noattr)))
                              (Tstruct _list noattr)) _next
                            (tptr (Tstruct _list noattr))))
                        (Ssequence
                          (Sassign
                            (Efield
                              (Ederef
                                (Etempvar _l (tptr (Tstruct _list noattr)))
                                (Tstruct _list noattr)) _next
                              (tptr (Tstruct _list noattr)))
                            (Etempvar _nl (tptr (Tstruct _list noattr))))
                          (Sreturn (Some (Econst_int (Int.repr 1) tint))))))
                    Sskip)
                  (Ssequence
                    (Sset _l (Etempvar _nl (tptr (Tstruct _list noattr))))
                    (Sset _nl
                      (Efield
                        (Ederef (Etempvar _nl (tptr (Tstruct _list noattr)))
                          (Tstruct _list noattr)) _next
                        (tptr (Tstruct _list noattr))))))))
            (Ssequence
              (Sassign
                (Ederef (Etempvar _mem (tptr (tptr (Tstruct _list noattr))))
                  (tptr (Tstruct _list noattr)))
                (Ecast (Econst_int (Int.repr 0) tint) (tptr tvoid)))
              (Sreturn (Some (Econst_int (Int.repr 0) tint))))))))))
|}.

Definition composites : list composite_definition :=
(Composite _list Struct
   (Member_plain _block_size tint ::
    Member_plain _next (tptr (Tstruct _list noattr)) :: nil)
   noattr :: nil).

Definition global_definitions : list (ident * globdef fundef type) :=
((___compcert_va_int32,
   Gfun(External (EF_runtime "__compcert_va_int32"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tvoid) :: nil) tuint cc_default)) ::
 (___compcert_va_int64,
   Gfun(External (EF_runtime "__compcert_va_int64"
                   (mksignature (AST.Xptr :: nil) AST.Xlong cc_default))
     ((tptr tvoid) :: nil) tulong cc_default)) ::
 (___compcert_va_float64,
   Gfun(External (EF_runtime "__compcert_va_float64"
                   (mksignature (AST.Xptr :: nil) AST.Xfloat cc_default))
     ((tptr tvoid) :: nil) tdouble cc_default)) ::
 (___compcert_va_composite,
   Gfun(External (EF_runtime "__compcert_va_composite"
                   (mksignature (AST.Xptr :: AST.Xlong :: nil) AST.Xptr
                     cc_default)) ((tptr tvoid) :: tulong :: nil)
     (tptr tvoid) cc_default)) ::
 (___compcert_i64_dtos,
   Gfun(External (EF_runtime "__compcert_i64_dtos"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tlong cc_default)) ::
 (___compcert_i64_dtou,
   Gfun(External (EF_runtime "__compcert_i64_dtou"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tulong cc_default)) ::
 (___compcert_i64_stod,
   Gfun(External (EF_runtime "__compcert_i64_stod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tlong :: nil) tdouble cc_default)) ::
 (___compcert_i64_utod,
   Gfun(External (EF_runtime "__compcert_i64_utod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tulong :: nil) tdouble cc_default)) ::
 (___compcert_i64_stof,
   Gfun(External (EF_runtime "__compcert_i64_stof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tlong :: nil) tfloat cc_default)) ::
 (___compcert_i64_utof,
   Gfun(External (EF_runtime "__compcert_i64_utof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tulong :: nil) tfloat cc_default)) ::
 (___compcert_i64_sdiv,
   Gfun(External (EF_runtime "__compcert_i64_sdiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_udiv,
   Gfun(External (EF_runtime "__compcert_i64_udiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_smod,
   Gfun(External (EF_runtime "__compcert_i64_smod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umod,
   Gfun(External (EF_runtime "__compcert_i64_umod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_shl,
   Gfun(External (EF_runtime "__compcert_i64_shl"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_shr,
   Gfun(External (EF_runtime "__compcert_i64_shr"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tulong :: tint :: nil) tulong cc_default)) ::
 (___compcert_i64_sar,
   Gfun(External (EF_runtime "__compcert_i64_sar"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_smulh,
   Gfun(External (EF_runtime "__compcert_i64_smulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umulh,
   Gfun(External (EF_runtime "__compcert_i64_umulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___builtin_ais_annot,
   Gfun(External (EF_builtin "__builtin_ais_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_bswap64,
   Gfun(External (EF_builtin "__builtin_bswap64"
                   (mksignature (AST.Xlong :: nil) AST.Xlong cc_default))
     (tulong :: nil) tulong cc_default)) ::
 (___builtin_bswap,
   Gfun(External (EF_builtin "__builtin_bswap"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap32,
   Gfun(External (EF_builtin "__builtin_bswap32"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap16,
   Gfun(External (EF_builtin "__builtin_bswap16"
                   (mksignature (AST.Xint16unsigned :: nil)
                     AST.Xint16unsigned cc_default)) (tushort :: nil) tushort
     cc_default)) ::
 (___builtin_clz,
   Gfun(External (EF_builtin "__builtin_clz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_clzl,
   Gfun(External (EF_builtin "__builtin_clzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_clzll,
   Gfun(External (EF_builtin "__builtin_clzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctz,
   Gfun(External (EF_builtin "__builtin_ctz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_ctzl,
   Gfun(External (EF_builtin "__builtin_ctzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctzll,
   Gfun(External (EF_builtin "__builtin_ctzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_fabs,
   Gfun(External (EF_builtin "__builtin_fabs"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fabsf,
   Gfun(External (EF_builtin "__builtin_fabsf"
                   (mksignature (AST.Xsingle :: nil) AST.Xsingle cc_default))
     (tfloat :: nil) tfloat cc_default)) ::
 (___builtin_fsqrt,
   Gfun(External (EF_builtin "__builtin_fsqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_sqrt,
   Gfun(External (EF_builtin "__builtin_sqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_memcpy_aligned,
   Gfun(External (EF_builtin "__builtin_memcpy_aligned"
                   (mksignature
                     (AST.Xptr :: AST.Xptr :: AST.Xlong :: AST.Xlong :: nil)
                     AST.Xvoid cc_default))
     ((tptr tvoid) :: (tptr tvoid) :: tulong :: tulong :: nil) tvoid
     cc_default)) ::
 (___builtin_sel,
   Gfun(External (EF_builtin "__builtin_sel"
                   (mksignature (AST.Xbool :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tbool :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot,
   Gfun(External (EF_builtin "__builtin_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot_intval,
   Gfun(External (EF_builtin "__builtin_annot_intval"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xint
                     cc_default)) ((tptr tschar) :: tint :: nil) tint
     cc_default)) ::
 (___builtin_membar,
   Gfun(External (EF_builtin "__builtin_membar"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_va_start,
   Gfun(External (EF_builtin "__builtin_va_start"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_va_arg,
   Gfun(External (EF_builtin "__builtin_va_arg"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_va_copy,
   Gfun(External (EF_builtin "__builtin_va_copy"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: (tptr tvoid) :: nil) tvoid
     cc_default)) ::
 (___builtin_va_end,
   Gfun(External (EF_builtin "__builtin_va_end"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_unreachable,
   Gfun(External (EF_builtin "__builtin_unreachable"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_expect,
   Gfun(External (EF_builtin "__builtin_expect"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___builtin_fmax,
   Gfun(External (EF_builtin "__builtin_fmax"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmin,
   Gfun(External (EF_builtin "__builtin_fmin"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmadd,
   Gfun(External (EF_builtin "__builtin_fmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fmsub,
   Gfun(External (EF_builtin "__builtin_fmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmadd,
   Gfun(External (EF_builtin "__builtin_fnmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmsub,
   Gfun(External (EF_builtin "__builtin_fnmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_read16_reversed,
   Gfun(External (EF_builtin "__builtin_read16_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint16unsigned
                     cc_default)) ((tptr tushort) :: nil) tushort
     cc_default)) ::
 (___builtin_read32_reversed,
   Gfun(External (EF_builtin "__builtin_read32_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tuint) :: nil) tuint cc_default)) ::
 (___builtin_write16_reversed,
   Gfun(External (EF_builtin "__builtin_write16_reversed"
                   (mksignature (AST.Xptr :: AST.Xint16unsigned :: nil)
                     AST.Xvoid cc_default))
     ((tptr tushort) :: tushort :: nil) tvoid cc_default)) ::
 (___builtin_write32_reversed,
   Gfun(External (EF_builtin "__builtin_write32_reversed"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tuint) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_debug,
   Gfun(External (EF_external "__builtin_debug"
                   (mksignature (AST.Xint :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tint :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (_mem_alloc, Gfun(Internal f_mem_alloc)) :: nil).

Definition public_idents : list ident :=
(_mem_alloc :: ___builtin_debug :: ___builtin_write32_reversed ::
 ___builtin_write16_reversed :: ___builtin_read32_reversed ::
 ___builtin_read16_reversed :: ___builtin_fnmsub :: ___builtin_fnmadd ::
 ___builtin_fmsub :: ___builtin_fmadd :: ___builtin_fmin ::
 ___builtin_fmax :: ___builtin_expect :: ___builtin_unreachable ::
 ___builtin_va_end :: ___builtin_va_copy :: ___builtin_va_arg ::
 ___builtin_va_start :: ___builtin_membar :: ___builtin_annot_intval ::
 ___builtin_annot :: ___builtin_sel :: ___builtin_memcpy_aligned ::
 ___builtin_sqrt :: ___builtin_fsqrt :: ___builtin_fabsf ::
 ___builtin_fabs :: ___builtin_ctzll :: ___builtin_ctzl :: ___builtin_ctz ::
 ___builtin_clzll :: ___builtin_clzl :: ___builtin_clz ::
 ___builtin_bswap16 :: ___builtin_bswap32 :: ___builtin_bswap ::
 ___builtin_bswap64 :: ___builtin_ais_annot :: ___compcert_i64_umulh ::
 ___compcert_i64_smulh :: ___compcert_i64_sar :: ___compcert_i64_shr ::
 ___compcert_i64_shl :: ___compcert_i64_umod :: ___compcert_i64_smod ::
 ___compcert_i64_udiv :: ___compcert_i64_sdiv :: ___compcert_i64_utof ::
 ___compcert_i64_stof :: ___compcert_i64_utod :: ___compcert_i64_stod ::
 ___compcert_i64_dtou :: ___compcert_i64_dtos :: ___compcert_va_composite ::
 ___compcert_va_float64 :: ___compcert_va_int64 :: ___compcert_va_int32 ::
 nil).

Definition prog : Clight.program := 
  mkprogram composites global_definitions public_idents _main Logic.I.

Require Import VST.floyd.proofauto.

#[export] Instance CompSpecs : compspecs. make_compspecs prog. Defined.
Definition Vprog : varspecs. mk_varspecs prog. Defined.
Definition t_struct_list := Tstruct _list noattr.
Parameter store_block: val -> Z -> mpred.
Fixpoint listrep (contents: list Z) (x: val) : mpred :=
 match contents with
 | sz :: hs =>
              EX y:val,
                data_at Ews t_struct_list (Vint (Int.repr sz),y) x *
                store_block x sz *
                listrep hs y
 | nil => !! (x = nullval) && emp
 end.

Arguments listrep contents x : simpl never.
Local Open Scope logic.

Lemma listrep_local_facts:
  forall l p,
     listrep l p
     |-- !! (is_pointer_or_null p).
Proof.
  intros.
  revert p; induction l; intros.
  + unfold listrep; entailer!.
  + unfold listrep; fold listrep.
    Intros y.
    sep_apply IHl.
    entailer!.
Qed.

Hint Resolve listrep_local_facts : saturate_local.

Lemma listrep_valid_pointer:
  forall contents p,
    listrep contents p |-- valid_pointer p.
Proof.
  destruct contents; unfold listrep; fold listrep; intros.
  + Intros.
    subst.
    auto with valid_pointer.
  + Intros y.
    auto with valid_pointer.
Qed.

Hint Resolve listrep_valid_pointer : valid_pointer.

Lemma listrep_null: forall contents,
  listrep contents nullval = !!(contents = nil) && emp.
Proof.
  destruct contents; unfold listrep; fold listrep.
  + apply pred_ext; entailer!.
  + apply pred_ext.
    - Intros y. entailer!. destruct H; contradiction.
    - Intros. discriminate H.
Qed.

Lemma listrep_is_null: forall l p,
  p = nullval ->
  listrep l p |-- !!(l = nil) && emp.
Proof.
  intros.
  destruct l.
  + entailer!.
    unfold listrep.
    entailer!.
  + subst p.
    unfold listrep; fold listrep.
    Intros y.
    entailer.
    destruct H; contradiction.
Qed.

Lemma listrep_isptr: forall l p,
  isptr p ->
  listrep l p
  |-- EX x l' q, !!(l = x :: l') &&
      data_at Ews t_struct_list (Vint (Int.repr x), q) p *
      store_block p x *
      listrep l' q.
Proof.
  intros.
  destruct l.
  + unfold listrep.
    entailer!.
  + unfold listrep at 1; fold listrep.
    Intros y.
    Exists z l y.
    entailer!.
Qed.

Lemma listrep_is_not_null: forall l p,
  p <> nullval ->
  listrep l p
  |-- EX x l' q, !!(l = x :: l') &&
      data_at Ews t_struct_list (Vint (Int.repr x), q) p *
      store_block p x *
      listrep l' q.
Proof.
  intros.
  destruct l.
  + unfold listrep.
    entailer!.
  + unfold listrep at 1; fold listrep.
    Intros y.
    Exists z l y.
    entailer!.
Qed.

Definition lseg (contents: list Z) (x z: val) : mpred :=
  ALL cts2: list Z, listrep cts2 z -* listrep (contents++cts2) x.

Lemma emp_lseg: forall x: val,
  emp |-- lseg nil x x.
Proof.
  intros.
  unfold lseg.
  apply allp_right; intro. simpl. cancel_wand.
Qed.

Lemma lseg_lseg: forall p q r xs1 xs2,
  lseg xs1 p q * lseg xs2 q r |--
  lseg (xs1 ++ xs2) p r.
Proof.
  intros.
  unfold lseg.
  apply allp_right; intros.
  rewrite <- app_assoc.
  rewrite wand_sepcon_adjoint.
  apply (allp_left _ (xs2 ++ v)).
  rewrite <- wand_sepcon_adjoint.
  rewrite sepcon_comm.
  rewrite wand_sepcon_adjoint.
  apply (allp_left _ v).
  rewrite <- wand_sepcon_adjoint.
  rewrite <- wand_sepcon_adjoint.
  rewrite sepcon_comm.
  rewrite <- sepcon_assoc.
  sep_apply modus_ponens_wand.
  sep_apply modus_ponens_wand.
  entailer!.
Qed.

Lemma lseg_listrep: forall p q xs1 xs2,
  lseg xs1 p q * listrep xs2 q |--
  listrep (xs1 ++ xs2) p.
Proof.
  intros.
  unfold lseg.
  rewrite wand_sepcon_adjoint.
  apply (allp_left _ xs2).
  entailer!.
Qed.

Lemma lseg1: forall p q sz,
  data_at Ews t_struct_list (Vint (Int.repr sz), q) p *
  store_block p sz |-- lseg [sz] p q.
Proof.
  intros.
  unfold lseg.
  apply allp_right; intros.
  simpl.
  rewrite <- wand_sepcon_adjoint.
  unfold listrep; fold listrep.
  Exists q.
  entailer!.
Qed.

Lemma listrep1: forall p sz,
  data_at Ews t_struct_list (Vint (Int.repr sz), nullval) p *
  store_block p sz |-- listrep [sz] p.
Proof.
  intros.
  unfold listrep.
  Exists nullval.
  entailer!.
Qed.

Definition mem_alloc_post
             (r: Z)
             (contents: list Z)
             (free_list: val)
             (mem: val)
             (size: Z): mpred :=
  (EX (l: val),
    !! (r = 0) &&
    !! (Forall (fun x => x < size) contents) &&
    listrep contents l *
    data_at Ews (tptr t_struct_list) l free_list *
    data_at Ews (tptr t_struct_list) nullval mem) ||
  (EX (xs1: list Z) (sz: Z) (xs2: list Z) (l p q: val),
    !! (r = 1) &&
    !! (Forall (fun x => x < size) xs1) &&
    !! (contents = xs1 ++ sz :: xs2) &&
    !! (sz >= size) &&
    (listrep (xs1 ++ xs2) l *
    data_at Ews (tptr t_struct_list) l free_list *
    data_at Ews (tptr t_struct_list) p mem *
    data_at Ews t_struct_list (Vint (Int.repr sz), q) p *
    store_block p sz)).

Definition mem_alloc_spec :=
 DECLARE _mem_alloc
  WITH contents: list Z, l: val, free_list: val, mem: val, size: Z
  PRE [ tptr (tptr t_struct_list) , tptr (tptr t_struct_list), tint]
     PROP (Int.min_signed <= size <= Int.max_signed;
           Forall (fun x => Int.min_signed <= x <= Int.max_signed) contents)
     PARAMS (free_list; mem; Vint (Int.repr (size))) GLOBALS()
     SEP (listrep contents l;
          data_at Ews (tptr t_struct_list) l free_list;
          data_at_ Ews (tptr t_struct_list) mem)
  POST [ tint ]
    EX r: Z,
     PROP ()
     RETURN (Vint (Int.repr r))
     SEP (mem_alloc_post r contents free_list mem size).

Definition Gprog : funspecs :=   ltac:(with_library prog [ mem_alloc_spec ]).

Lemma body_mem_alloc:
  semax_body Vprog Gprog f_mem_alloc mem_alloc_spec.
Proof.
  start_function.
(* 请在此处填入你的证明，以_[Qed]_结束。*)
Admitted.