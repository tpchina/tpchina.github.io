From Coq Require Import List Lia.
Import ListNotations.

Inductive tree (A : Type) : Type :=
| Leaf : tree A
| Node : A -> tree A -> tree A -> tree A.

Arguments Leaf {A}.
Arguments Node {A} _ _ _.

Fixpoint mirror {A : Type} (t : tree A) : tree A :=
  match t with
  | Leaf => Leaf
  | Node x l r => Node x (mirror r) (mirror l)
  end.

Definition is_symmetric {A : Type} (t : tree A) : Prop :=
  t = mirror t.

Fixpoint check_mirror {A : Type} (t1 t2 : tree A) : Prop :=
  match t1, t2 with
  | Leaf, Leaf => True
  | Node x1 l1 r1, Node x2 l2 r2 =>
    (x1 = x2) /\ (check_mirror l1 r2) /\ (check_mirror r1 l2)
  | _, _ => False
  end.

Definition check_symmetric {A : Type} (t : tree A) : Prop :=
  match t with
  | Leaf => True
  | Node x l r => check_mirror l r
  end.

Lemma check_mirror_correct : forall {A : Type} (t1 t2 : tree A),
  check_mirror t1 t2 <-> t1 = mirror t2.
Admitted.

Theorem check_symmetric_correct: forall {A : Type} (t: tree A),
  check_symmetric t <-> is_symmetric t.
Admitted.