From Coq Require Import List Lia FunctionalExtensionality.
Import ListNotations.

Section ProblemB.

  Parameter C: nat. 
  Parameter N: nat. 

  Hypothesis posN: N > 0.

  Parameter caps: nat -> nat.
  Parameter vals: nat -> nat. 

  Definition clear (s: nat -> option bool) i :=
    fun j => if Nat.eqb j i then None else s j. 

  Fixpoint val_in_knapsack (s: nat -> option bool) (n: nat) (c_rem: nat) : option nat := 
    match n with 
      0 => Some 0 
    | S n' => 
      let s' := clear s n in 
        match s n with 
          Some true => 
            if Nat.leb (caps n) c_rem then 
              match (val_in_knapsack s' n' (c_rem - (caps n))) with 
                Some v => Some (v + vals n)
              | _ => None
              end
            else 
              None 
        | Some false => 
            val_in_knapsack s' n' c_rem 
        | None => None
        end 
    end. 

  Definition wf (s: nat -> option bool) (n: nat) :=
    forall i, s i <> None <-> 1 <= i <= n. 


  Definition opt_s (s: nat -> option bool) n c_rem :=
    wf s n /\
      forall s' v1 v2,
        wf s' n ->
        val_in_knapsack s' n c_rem = Some v1 ->
        val_in_knapsack s n c_rem = Some v2 ->
        v1 <= v2.

  Lemma wf_clr:
    forall s n,
      1 <= n <= N -> wf s n -> wf (clear s n) (n - 1). 
  Admitted.

  Definition set_s (s: nat -> option bool) i b :=
    fun j => if Nat.eqb j i then Some b else s j. 

  Lemma wf_set_s: 
    forall s n b, 
      1 <= n -> 
      wf s (n - 1) ->
      wf (set_s s n b) n.
  Admitted.


  Lemma clr_set:
    forall s n,
      s n = None -> 
      clear (fun j : nat => if Nat.eqb j n then Some true else s j) n = s.
  Admitted.

  Theorem optimal_substructure:
    forall s n c_rem,
      1 <= n <= N ->
      s n = Some true ->
      caps n <= c_rem -> 
      opt_s s n c_rem ->
      opt_s (clear s n) (n - 1) (c_rem - caps n).
  Admitted.
  
End ProblemB.