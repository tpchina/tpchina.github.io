From Coq Require Import Znumtheory Zdiv ZArith.

Section SimpleChineseRemainder .

Open Scope Z_scope .

Definition modulo (a b n : Z) : Prop := (n | (a - b)) .
Notation "( a === b [ n ])" := (modulo a b n). 

Lemma modulo_tran : forall a b c n : Z, 
    (a === b [ n ]) -> (b === c [ n ]) -> (a === c [ n ]) .
Admitted.

Lemma modulo_mult_subst : forall a b c n : Z,
    (a === b [ n ]) -> (a * c === b * c [ n ]) .
Admitted.

Hypothesis m n : Z .
Hypothesis co_prime : rel_prime m n .

Theorem modulo_inv : forall m n : Z, rel_prime m n ->
                       exists x : Z, (m * x === 1 [ n ]) .

Admitted.

Theorem SimpleChineseRemainder : forall a b : Z,
  exists x : Z, (x === a [ m ]) /\ (x === b [ n ]) .

Admitted.

End SimpleChineseRemainder .

