From Coq Require Import List Lia.

Definition Tick (A: Type): Type := (A * nat)%type.

Definition ret {A: Type} (a: A): Tick A := (a, 0).

Definition bind {A B: Type} (f: Tick A) (g: A -> Tick B): Tick B :=
  let (r1, c1) := f in
  let (r2, c2) := g r1 in (r2, c1 + c2).

Definition tick (n: nat): Tick unit := (tt, n).

Declare Scope monad_scope.
Delimit Scope monad_scope with monad.
Notation "x <- c1 ;; c2" := (bind c1 (fun x => c2))
  (at level 61, c1 at next level, right associativity) : monad_scope.
Notation " x : T <- c1 ;; c2" :=(bind c1 (fun x : T => c2))
  (at level 61, c1 at next level, right associativity) : monad_scope.
Notation "' pat <- c1 ;; c2" :=
  (bind c1 (fun x => match x with pat => c2 end))
  (at level 61, pat pattern, c1 at next level, right associativity) : monad_scope.
Notation "e1 ;; e2" := (bind e1 (fun _: unit => e2))
  (at level 61, right associativity) : monad_scope.
Local Open Scope monad.

Record queue (A: Type): Type :=
{
    inq: list A;
    outq: list A;
}.

Arguments inq {A} (_).
Arguments outq {A} (_).

Definition queue_empty (A: Type): Tick (queue A) :=
  ret {| inq := nil; outq := nil |}.

Fixpoint rev_app {A: Type} (l1 l2: list A): Tick (list A) :=
  match l1 with
  | nil =>    ret l2
  | h :: t => tick 1;;
              rev_app t (h :: l2)
  end.

Definition queue_in_to_out {A: Type} (q: queue A): Tick (queue A) :=
  r <- rev_app q.(inq) q.(outq);;
  ret {| inq := nil; outq := r |}.

Definition queue_enq {A: Type} (q: queue A) (x: A): Tick (queue A) :=
  tick 1;;
  ret {| inq := x :: q.(inq); outq := q.(outq) |}.

Definition queue_deq {A: Type} (q: queue A): Tick (option A * queue A) :=
  tick 1;;
  match q.(outq) with
  | h :: t => ret (Some h, {| inq := q.(inq); outq := t |})
  | nil    => q' <- queue_in_to_out q;;
              match q'.(outq) with
              | nil => ret (None, q')
              | h :: t => ret (Some h, {| inq := nil; outq := t |})
              end
  end.

Fixpoint seq_op_queue {A: Type} (q: queue A) (ops: list (option A)):
  Tick (queue A) :=
  match ops with
  | nil => ret q
  | op :: ops' =>
      match op with
      | Some x =>
          q' <- queue_enq q x;;
          seq_op_queue q' ops'
      | None =>
          '(_, q') <- queue_deq q;;
          seq_op_queue q' ops'
      end
  end.

Definition seq_op_queue_from_empty {A: Type} (ops: list (option A)):
  Tick (queue A):=
  q <- queue_empty A;;
  seq_op_queue q ops.


Theorem seq_op_queue_from_empty_cost {A: Type} (ops: list (option A)):
  snd (seq_op_queue_from_empty ops) <= 2 * (length ops).
Admitted.
