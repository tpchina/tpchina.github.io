From Coq Require Import List Lia.
Import ListNotations.
Section ProblemA. 
          
Parameter P: nat -> Prop.
Parameter Q: nat -> Prop.
Parameter R: nat -> nat -> Prop. 

Inductive A : nat -> Prop :=
  ca0: forall n, P n -> A n
| ca1: forall n1, (forall n2, R n1 n2 -> B n2) -> A n1
with B: nat -> Prop :=
  cb0: forall n, Q n -> B n
| cb1: forall n1 n2, R n1 n2 -> A n2 -> B n1. 

Scheme a_ind := Induction for A Sort Prop 
  with b_ind := Induction for B Sort Prop.

Theorem neg_a:
  (forall n, ~P n /\ ~Q n) ->
  (forall n1, exists n2, R n1 n2) -> 
  (forall n, A n -> False).  
Admitted.

End ProblemA.