From Coq Require Import ZArith Bool Lia.
Open Scope Z_scope.

Check Z.testbit.

(* 下面的Z相关Lemma在证明过程中可能会被用到： 5个标准库中lemma和 3个自定义lemma *)
Check Z.bit0_odd.
Check Z.bit0_mod.
Check Z_div_mod_eq_full.
Check Zodd_mod.
Check Z.testbit_succ_r.
Check Z.odd_sub.

Lemma Zodd_b2z : forall b, Z.odd (Z.b2z b) = b.
Proof.
  destruct b; reflexivity.
Qed.

Lemma decomp : forall x,
    (x = 2 * (x / 2) + Z.b2z (Z.odd x))%Z.
Proof.
  intros.
  rewrite <- Z.bit0_odd.
  rewrite Z.bit0_mod.
  apply Z_div_mod_eq_full.
Qed.

Ltac Zify.zify_convert_to_euclidean_division_equations_flag ::= constr:(true).

Lemma b2z_div2 : forall b,
    (Z.b2z b / 2 = 0)%Z.
Proof.
  destruct b; reflexivity.
Qed.

Lemma b2z_exists: forall x y c0, 
  exists cr,
  Z.b2z (negb (Z.odd x) && Z.odd y) +
  Z.b2z (negb (xorb (Z.odd x) (Z.odd y)) && c0) = Z.b2z cr.
Admitted.

Axiom sub_borrow_bit : Z -> Z -> bool -> nat -> bool.

(* 请替换 sub_borrow_bit 为下列代码
Fixpoint sub_borrow_bit (x y : Z) (c:bool) (n:nat) :=
  match n with
  | O => c
  | S n' =>
      let pc := sub_borrow_bit x y c n' in
      xxx
  end.*)

Lemma sub_shift : forall a b,
    ((a - b) / 2 =
        (a / 2 - (b / 2) - (Z.b2z (negb (Z.odd a) && Z.odd b))))%Z.
Proof.
Admitted.

Lemma sub_borrow_bit_eq: forall n x y cr c0
  (CR: Z.b2z (negb (Z.odd x) && Z.odd y) + Z.b2z (negb (xorb (Z.odd x) (Z.odd y)) && c0) = Z.b2z cr),
    sub_borrow_bit (x / 2) (y / 2) cr n =
    negb (Z.testbit x (Z.of_nat n)) && Z.testbit y (Z.of_nat n)
    || sub_borrow_bit x y c0 n && negb (xorb (Z.testbit x (Z.of_nat n)) (Z.testbit y (Z.of_nat n))).
Proof.
Admitted.

Lemma xtestbit_sub_sound : forall n x y c0,
    Z.testbit (x - y - Z.b2z c0) (Z.of_nat n) =
      xorb (xorb (Z.testbit x (Z.of_nat n))
              (Z.testbit y (Z.of_nat n))) (sub_borrow_bit x y c0 n).
Admitted.

Lemma testbit_sub_sound : forall n x y,
    Z.testbit (x - y) (Z.of_nat n) =
      xorb (xorb (Z.testbit x (Z.of_nat n))
              (Z.testbit y (Z.of_nat n))) (sub_borrow_bit x y false n).
Proof.
  intros.
  rewrite <- xtestbit_sub_sound.
  f_equal. simpl; ring.
Qed.