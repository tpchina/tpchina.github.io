#include <stddef.h>

struct list {int block_size; struct list * next;};

int mem_alloc (struct list * * free_list, struct list * * mem, int size) {
  struct list * l;
  l = * free_list;
  if (l == NULL) {
    * mem = NULL;
    return 0;
  }
  int sz;
  sz = l -> block_size;
  if (sz >= size) {
    * mem = l;
    l = l -> next;
    * free_list = l;
    return 1;
  }
  struct list * nl;
  nl = l -> next;
  while (nl != NULL) {
    sz = nl -> block_size;
    if (sz >= size) {
      * mem = nl;
      nl = nl -> next;
      l -> next = nl;
      return 1;
    }
    l = nl;
    nl = nl -> next;
  }
  * mem = NULL;
  return 0;
}

