From Coq Require Import Arith List Lia.

Definition neighbor_nonequal (xs : list nat) : Prop :=
  forall i, i < length xs - 1 -> nth i xs 0 <> nth (i + 1) xs 0.

Definition is_local_min (xs : list nat) (i : nat) : Prop :=
  i < length xs /\
  (i = 0 \/ nth i xs 0 < nth (i - 1) xs 0) /\
  (i = length xs - 1 \/ nth i xs 0 < nth (i + 1) xs 0).

Lemma ge_exists:
 forall  right left (g : right > left)
  (n : left + 1 <> right),
  exists n0 : nat, right = n0 + left /\ n0 > 1.
Proof.
  induction right; simpl; intros.
  - inversion g.
  - destruct left.
    + exists (S right).
      lia.
    + specialize (IHright left).
      apply Arith_base.gt_S_n_stt in g.
      rewrite plus_Sn_m in n.
      rewrite Nat.succ_inj_wd_neg in n.
      specialize (IHright g n).
      destruct IHright as (k & Hk1 & Hk2).
      exists k.
      lia.
Qed.

Lemma div2_plus_2n: forall n k, Nat.div2 (k + (n + n)) = Nat.div2 k + n.
Proof.
  induction n; simpl; intros.
  - rewrite ! Nat.add_0_r.
    lia.
  - specialize (IHn (S (S k))).
    replace (S (S k) + (n + n)) with (k + S (n + S n))  in IHn by lia.
    rewrite IHn.
    simpl.
    lia.
Qed.

Lemma div2_le: forall n k,
  n <= k -> Nat.div2 n <= Nat.div2 k.
Proof.
  intros.
  pose proof (Nat.Div0.div_le_mono n k 2) as Heq.
  rewrite ! Nat.div2_div.
  apply Heq.
  lia.
Qed.

Inductive local_min : forall (xs : list nat) (l r i: nat), Prop :=
  | case_le_right_left : forall xs l r,
      r <= l -> 
      local_min xs l r l
  | case_left_plus_1_eq_right_l: forall xs l r,
      l < r -> 
      r = l+1 ->
      nth l xs 0 < nth r xs 0 ->
      local_min xs l r l
  | case_left_plus_1_eq_right_r: forall xs l r,
      l < r -> 
      r = l+1 ->
      nth r xs 0 <= nth l xs 0 ->
      local_min xs l r r
  | case_mid_1: forall xs l r mid i,
      l < r -> 
      l+1 <> r ->
      mid = Nat.div2 (l + r) ->
      nth (mid - 1) xs 0 < nth mid xs 0 ->
      local_min xs l (mid - 1) i ->
      local_min xs l r i
  | case_mid_r: forall xs l r mid i,
      l < r -> 
      l+1 <> r ->
      mid = Nat.div2 (l + r) ->
      nth mid xs 0 <= nth (mid - 1) xs 0 ->
      local_min xs mid r i ->
      local_min xs l r i
.

Definition is_local_min_part (ls : list nat) (l r i: nat) : Prop :=
  i >= l /\ i <= r /\
  (i = 0 \/ (i < length ls /\ (i-1) < length ls /\ nth i ls 0 < nth (i-1) ls 0)) /\
  (i = length ls - 1 \/ (i < length ls /\ (i+1) < length ls /\ nth i ls 0 < nth (i+1) ls 0)).

Lemma local_min_correct_induct :
  forall xs a b i,
    neighbor_nonequal xs ->
    0 <= a -> a <= b -> b < length xs ->
    (a = 0 \/ (a < length xs /\ (a-1) < length xs /\ nth a xs 0 < nth (a-1) xs 0)) ->
    (b = length xs - 1 \/ (b < length xs /\ (b+1) < length xs /\ nth b xs 0 < nth (b+1) xs 0)) ->
    local_min xs a b i ->
    is_local_min_part xs a b i.
Proof.
  intros xs l r i H_neighbor H_a_lower H_ab H_b_upper H_a_cond H_b_cond Hi.
  unfold is_local_min_part.
  induction Hi; try lia.
  - assert (Heq: l = r) by lia.
    subst l.
    lia.

  - admit.

  - admit.

  - admit.

  - admit.
Admitted.

Theorem local_min_correct:
  forall xs i,
    neighbor_nonequal xs ->
    length xs > 0 ->
    local_min xs 0 (length xs - 1) i ->
    is_local_min xs i.
Admitted.