theory Problem9
  imports "HOL-Library.Monad_Syntax"
begin

section \<open>tick monad\<close>
type_synonym 'a tick_monad = "unit \<Rightarrow> 'a \<times> nat"

definition
  return :: "'a \<Rightarrow> 'a tick_monad" where
  "return a \<equiv> \<lambda>_. (a, 0)"

definition
  bind :: "'a tick_monad \<Rightarrow> ('a \<Rightarrow> 'b tick_monad) \<Rightarrow> 'b tick_monad"
  where
  "bind f g \<equiv> (\<lambda>_. (let (r1,t1) = f () in
                    let (r2,t2) = g r1 () in (r2, t1 + t2)))"

definition tick :: "nat \<Rightarrow> (unit) tick_monad"
  where "tick n \<equiv> \<lambda>_. ((), n)"

adhoc_overloading
  Monad_Syntax.bind \<rightleftharpoons> Problem9.bind (* Isabelle 2025 works *)
  (* Monad_Syntax.bind Tick_Monad.bind *) (* Isabelle 2023, 2024 works*)


section \<open>Queue\<close>

record 'a Queue = inq :: "'a list"
                  outq :: "'a list"

abbreviation "mk a b \<equiv> \<lparr>inq = a, outq = b\<rparr>"

definition empty :: "('a Queue) tick_monad"
  where "empty \<equiv> return (mk [] [])"

primrec aux :: "'a list \<Rightarrow> 'a list \<Rightarrow> ('a list) tick_monad"
  where "aux [] l = return l" |
        "aux (a#t) l = do { tick 1; aux t (a # l) }" 

definition in_to_out :: "'a Queue \<Rightarrow> ('a Queue) tick_monad"
  where "in_to_out q \<equiv> do { r \<leftarrow> aux (inq q) (outq q); return (mk [] r)}"

definition enq :: "'a Queue \<Rightarrow> 'a \<Rightarrow> ('a Queue) tick_monad"
  where "enq q x \<equiv> do {tick 1; return (mk (x#(inq q)) (outq q))}"

definition deq :: "'a Queue \<Rightarrow> ('a option \<times> 'a Queue) tick_monad"
  where "deq q \<equiv> do {
                       tick 1; 
                       case (outq q) of (h#t) \<Rightarrow> return (Some h, mk (inq q) t) |
                                        [] \<Rightarrow> do { p \<leftarrow> in_to_out q;
                                                   case (outq p) of [] \<Rightarrow> return (None, p) |
                                                                    (h#t) \<Rightarrow> return (Some h, mk (inq p) t)
                                                 }
                     }"


primrec seq_op_queue :: "'a Queue \<Rightarrow> ('a option) list \<Rightarrow> ('a Queue) tick_monad"
  where "seq_op_queue q [] = return q" |
        "seq_op_queue q (op#ops') = (case op of Some x \<Rightarrow> do {q' \<leftarrow> enq q x; seq_op_queue q' ops'} |
                                                None \<Rightarrow> do {(_,q') \<leftarrow> deq q; seq_op_queue q' ops'})"


definition seq_op_queue_from_empty :: "('a option) list \<Rightarrow> ('a Queue) tick_monad"
  where "seq_op_queue_from_empty ops \<equiv> do {q \<leftarrow> empty; seq_op_queue q ops}"


section \<open>Proof\<close>

definition Pot :: "'a tick_monad \<Rightarrow> nat \<Rightarrow> ('a \<Rightarrow> nat) \<Rightarrow> bool"
  where "Pot f pre_pot post_pot \<equiv> let (r,c) = f () in pre_pot \<ge> c + post_pot r"

primrec list_pot_lin :: "nat \<Rightarrow> 'a list \<Rightarrow> nat"
  where "list_pot_lin p [] = 0" |
        "list_pot_lin p (_ # t) = p + list_pot_lin p t"


theorem list_pot_share : "list_pot_lin (p1 + p2) l = list_pot_lin p1 l + list_pot_lin p2 l"
  apply(induct l) apply simp by simp

lemma list_pot_lin_length : "list_pot_lin p l = p * length l"
  apply(induct l) apply simp by simp


theorem empty_pot : "Pot (empty) 0 (\<lambda> q. list_pot_lin 1 (inq q))"
  by(simp add: Pot_def empty_def return_def)

lemma aux_tick: "(r,c) = aux h l () \<Longrightarrow> c = length h"
  apply(induct h arbitrary: r c l) apply(simp add:return_def)
  apply(simp add:tick_def bind_def)
  by (metis (lifting) case_prod_conv prod.inject surj_pair)

lemma aux_list: "(r,c) = aux h l () \<Longrightarrow> r = rev h @ l"
  apply(induction h arbitrary: r c l) apply(simp add:return_def)
  apply(simp add:tick_def bind_def)
  by (metis (no_types, lifting) case_prod_conv old.prod.inject surj_pair)

theorem in_to_out_pot : "Pot (in_to_out q) (list_pot_lin 1 (inq q)) (\<lambda> q. list_pot_lin 1 (inq q))"
  apply(simp add: Pot_def in_to_out_def bind_def) apply auto subgoal for r c
  proof -
    assume p1: "(case aux (inq q) (outq q) () of (r1, t1) \<Rightarrow> case return (mk [] r1) () of (r2, t2) \<Rightarrow> (r2, t1 + t2)) = (r, c)"
    then have "c = length (inq q)" using aux_tick[of _ _ "inq q" "outq q"] apply(simp add:return_def tick_def)
      by (metis (no_types, lifting) case_prod_conv prod.inject surj_pair) 
    moreover from p1 have "r = mk [] (rev (inq q) @ outq q)" 
      using aux_list[of _ _ "inq q" "outq q"] apply(simp add:return_def)
      by (metis (no_types, lifting) case_prod_conv old.prod.inject surj_pair)
    ultimately show "c + list_pot_lin (Suc 0) (inq r) \<le> list_pot_lin (Suc 0) (inq q)" using list_pot_lin_length
      by (metis Nat.add_0_right One_nat_def le_refl list.size(3) mult_1 select_convs(1))
  qed
  done

theorem enq_pot : "Pot (enq q x) (list_pot_lin 1 (inq q) + 2) (\<lambda> q. list_pot_lin 1 (inq q))"
  by(simp add: Pot_def enq_def bind_def tick_def return_def) 


lemma deq_cor1: "outq q = [] \<Longrightarrow> inq q = [] \<Longrightarrow> deq q () = ((a,b),c) \<Longrightarrow> a = None \<and> b = mk [] [] \<and> c = 1"
  by(simp add: deq_def bind_def tick_def return_def in_to_out_def) 

lemma deq_cor2: "outq q = [] \<Longrightarrow> inq q \<noteq> [] \<Longrightarrow> deq q () = ((a,b),c) \<Longrightarrow> a = Some (hd (rev (inq q))) \<and> b = mk [] (tl (rev (inq q))) \<and> c = 1 + length (inq q)"
  apply(simp add: deq_def bind_def tick_def return_def in_to_out_def) 
  apply(subgoal_tac "aux (inq q) [] () = (rev (inq q), length (inq q))") 
   prefer 2 using aux_list[of _ _ "inq q" "[]"] aux_tick[of _ _ "inq q" "[]"]
   apply (metis append_Nil2 surj_pair) 
  apply auto[1]
  by (simp add: list.case_eq_if return_def)+ 

lemma deq_cor3: "outq q \<noteq> [] \<Longrightarrow> deq q () = ((a,b),c) \<Longrightarrow> a = Some (hd (outq q)) \<and> b = mk (inq q) (tl (outq q)) \<and> c = 1"
  apply(simp add: deq_def bind_def tick_def return_def in_to_out_def)  apply auto
  by(simp add: list.case_eq_if return_def)+
  
theorem deq_pot : "Pot (deq q) (list_pot_lin 1 (inq q) + 1) (\<lambda> (_, q) => list_pot_lin 1 (inq q))"
  apply(simp add: Pot_def)
  apply(cases "outq q = []")
   apply(cases "inq q = []")
  using deq_cor1[of q] list_pot_lin_length
    apply fastforce
  using deq_cor2[of q] list_pot_lin_length
   apply (smt (verit) Nat.add_0_right One_nat_def add.commute add_Suc_right case_prodE2 case_prodI2 
          case_prod_conv lambda_one lambda_zero le_iff_add list_pot_lin.simps(1)
      nat_le_linear prod.case_distrib select_convs(1))
  using deq_cor3[of q] list_pot_lin_length
  using lambda_zero le_Suc_eq not_less_eq_eq plus_1_eq_Suc prod.case_distrib select_convs(1) by auto

theorem seq_op_queue_pot : "Pot (seq_op_queue q ops) (list_pot_lin 1 (inq q) + list_pot_lin 2 ops) (\<lambda> q. list_pot_lin 1 (inq q))"
  apply(simp add:Pot_def)
  apply(induct ops arbitrary:q)
   apply(simp add:seq_op_queue_def return_def) apply auto
proof -
  fix op ops q r c
  assume ih: "\<And>q. case seq_op_queue q ops () of (r, c) \<Rightarrow> c + list_pot_lin (Suc 0) (inq r) \<le> list_pot_lin (Suc 0) (inq q) + list_pot_lin 2 ops"
    and op: "(case op of None \<Rightarrow> deq q \<bind> (\<lambda>(_, q'). seq_op_queue q' ops) | Some x \<Rightarrow> enq q x \<bind> (\<lambda>q'. seq_op_queue q' ops)) () = (r, c)"
  show "c + list_pot_lin (Suc 0) (inq r) \<le> Suc (Suc (list_pot_lin (Suc 0) (inq q) + list_pot_lin 2 ops))"
  proof(cases op)
    case None
    with op have "(deq q \<bind> (\<lambda>(_, q'). seq_op_queue q' ops)) () = (r,c)" by simp
    then show ?thesis using ih[of "snd (fst ((deq q) ()))"] deq_pot[of q] apply(simp add:bind_def Pot_def) by fastforce
  next
    case (Some a)
    with op have "(enq q a \<bind> (\<lambda>q'. seq_op_queue q' ops)) () = (r, c)" by simp
    then show ?thesis using ih[of "fst (enq q a ())"] enq_pot[of q a] apply(simp add:bind_def Pot_def) by fastforce
  qed
qed
  

theorem seq_op_queue_from_empty_pot : "Pot (seq_op_queue_from_empty ops) (list_pot_lin 2 ops) (\<lambda> q. list_pot_lin 1 (inq q))"
  apply(simp add: Pot_def seq_op_queue_from_empty_def bind_def)
  using empty_pot seq_op_queue_pot[of "(fst (empty ()))" ops] 
  by(simp add:Pot_def empty_def return_def)
  
theorem seq_op_queue_from_empty_cost : "snd (seq_op_queue_from_empty ops ()) \<le> 2 * (length ops)"
  using seq_op_queue_from_empty_pot[of ops] list_pot_lin_length[of 2 ops] apply(simp add:Pot_def) by fastforce


end
