theory Problem6
  imports Main
begin

definition modulo :: "int \<Rightarrow> int \<Rightarrow> int \<Rightarrow> bool" where
  "modulo a b n \<equiv> n dvd (a - b)"

notation
  modulo ("(_ === _ [_] )" [30, 30] 50)

lemma modulo_trans:
  "a === b [n] \<Longrightarrow> b === c [n] \<Longrightarrow> a === c [n]"
  unfolding modulo_def
  by (metis mod_eq_dvd_iff)  (* sledgehammer *)


lemma modulo_mult_subst:
  "a === b [n] \<Longrightarrow> a * c === b * c [n]"
  unfolding modulo_def
  by (metis dvd_mult int_distrib(3) mult.commute) (* sledgehammer *)


lemma modulo_inv:
  assumes "coprime m n"
  shows "\<exists>x. m * x === 1 [n]"
proof -
  obtain u v where "u * m + v * n = gcd m n"
    using bezout_int by blast  (* sledgehammer *)
  have "gcd m n = 1"
    by (simp add: assms)  (* sledgehammer *)
  have "u * m + v * n = 1"
    by (simp add: \<open>gcd m n = 1\<close> \<open>u * m + v * n = gcd m n\<close>)
  show ?thesis
    apply (rule exI[where x=u])
    unfolding modulo_def
    by (metis \<open>u * m + v * n = 1\<close> diff_add_eq diff_self dvd_0_right
              mult.commute zdvd_reduce)  (* sledgehammer *)
qed

theorem simple_chinese_remainder:
  fixes a b m n :: int
  assumes "coprime m n"
  shows "\<exists>x. (x === a [m]) \<and> (x === b [n])"
proof -
  obtain m' where m1: "m * m' === 1 [n]"
    using assms modulo_inv by auto 
  have m2: "m * m' * (b - a) === b - a [n]"
    using m1 unfolding modulo_def
    by (metis modulo_def modulo_mult_subst mult_cancel_right1)  (* sledgehammer *)
  show ?thesis
    apply (rule exI[where x="a + m * m' * (b - a)"])
    apply (rule conjI)
    apply (simp add: modulo_def)
    using m2 unfolding modulo_def
    by (metis add.commute diff_diff_eq2)  (* sledgehammer *)
qed

end
