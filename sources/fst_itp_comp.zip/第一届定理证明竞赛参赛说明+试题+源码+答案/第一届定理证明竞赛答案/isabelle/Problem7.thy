theory Problem7
imports
  Main
begin

definition xorb :: "bool => bool => bool" where
"xorb b1 b2 = (if b1 then if b2 then False else True else b2)"

definition b2z :: "bool => int" where
"b2z b = (if b then 1 else 0)"

lemma b2z_div2 : "b2z b div 2 = 0" using b2z_def by auto

lemma odd_sub : "odd (n - m) = xorb (odd (n::int)) (odd m)"
  using xorb_def
  by simp

lemma Zodd_b2z : "odd (b2z b) = b" using b2z_def by auto


lemma b2z_exist: "\<exists> cr. b2z cr = b2z (Not (odd x) \<and> odd y) + b2z (Not (xorb (odd x) (odd y)) \<and> c0)"
  apply (simp add: b2z_def)
  using xorb_def by auto

fun sub_borrow_bit :: "int \<Rightarrow> int \<Rightarrow> bool \<Rightarrow> nat \<Rightarrow> bool" where
"sub_borrow_bit _ _ c 0 = c" |
"sub_borrow_bit x y c (Suc n) = (
  let pc = sub_borrow_bit x y c n in
   ((Not (bit x n)) \<and> (bit y  n)) \<comment>\<open> x[n] = 0 and y[n] = 1 \<close>
    \<or>
   ( pc \<and> (Not (xorb (bit x n) (bit y n) )))   \<comment>\<open> x[n] = y[n] \<close>
)"

lemma sub_shift : "(a - b) div 2 = a div 2 - b div 2 - b2z (Not (odd a) \<and> odd b)"
  apply (simp add: b2z_def)
  apply (cases "even a"; cases "odd b"; simp)
  subgoal
    by presburger
  subgoal 
    by presburger
  subgoal 
    by presburger
  done

lemma borrow_bit_rew: "
    sub_borrow_bit x y c n =
( case n of 0 \<Rightarrow> c | Suc n \<Rightarrow> 
   (let pc = sub_borrow_bit x y c n in
    ( ( (Not (bit x n)) \<and> (bit y  n)) \<or>
                      ( pc \<and> (Not (xorb (bit x n) (bit y n)))))
)
)
" apply (cases n; simp)
  done

lemma sub_borrow_bit_eq:
"b2z (Not (odd x) \<and> odd y) + b2z (Not (xorb (odd x) (odd y)) \<and> c0) = b2z cr \<Longrightarrow>
sub_borrow_bit (x div 2) (y div 2) cr n =
(Not (bit x n) \<and> bit y n) \<or> (sub_borrow_bit x y c0 n \<and> Not (xorb (bit x n) (bit y n)))"
proof(induction n arbitrary: x y c0 cr)
  case 0
  then show ?case using b2z_def xorb_def
  proof (cases cr; cases c0; cases "odd x"; cases "odd y"; simp add: bit_0)
  qed
next
  case (Suc n)
  then show ?case
    using bit_Suc sub_borrow_bit.simps(2) xorb_def
    by metis 
qed                                                                                                          

lemma sub_borrow_bit_eq1: "
b2z cr = b2z (even x \<and> odd y) + b2z (\<not> xorb (odd x) (odd y) \<and> c) \<Longrightarrow>
    sub_borrow_bit (x div 2) (y div 2) cr n1 = (\<not> bit x n1 \<and> bit y n1 \<or> sub_borrow_bit x y c n1 \<and> \<not> xorb (bit x n1) (bit y n1))"
proof(induction n1 arbitrary: x y c cr)
  case 0
  then show ?case  using b2z_def xorb_def
  proof (cases cr; cases c; cases "odd x"; cases "odd y"; simp add: bit_0)
  qed
next
  case (Suc n1)
  then show ?case 
    using bit_Suc sub_borrow_bit.simps(2) xorb_def
    by metis 
qed

lemma sub_test:
"b2z cr = b2z (\<not> odd x \<and> odd y) + 0 + b2z (\<not> xorb (odd x) (odd y) \<and> c) \<Longrightarrow>
    sub_borrow_bit (x div 2) (y div 2) cr n1 = sub_borrow_bit x y c (Suc n1)"
  using sub_borrow_bit_eq1
  by simp


lemma test: "(\<And>x y c. bit (x - y - b2z c) n1 = xorb (xorb (bit x n1) (bit y n1)) (sub_borrow_bit x y c n1)) \<Longrightarrow>
    b2z cr = b2z (\<not> odd x \<and> odd y) + 0 + b2z (\<not> xorb (odd x) (odd y) \<and> c) \<Longrightarrow>
    bit (x div 2 - y div 2 - b2z cr) n1 =
    xorb (xorb (bit (x div 2) n1) (bit (y div 2) n1)) (sub_borrow_bit x y c (Suc n1))"


      apply (subgoal_tac "
  bit (x div 2 - y div 2 - b2z cr) n1 = xorb (xorb (bit (x div 2) n1) (bit (y div 2) n1)) (sub_borrow_bit (x div 2) (y div 2) cr n1)")
    prefer 2
     apply blast
apply (rule trans[of  _ "xorb (xorb (bit (x div 2) n1) (bit (y div 2) n1)) (sub_borrow_bit (x div 2) (y div 2) cr n1)" _])
  subgoal by simp 
  apply (subgoal_tac "sub_borrow_bit (x div 2) (y div 2) cr n1 = sub_borrow_bit x y c (Suc n1)")
   prefer 2
  subgoal using sub_test
    by simp

  by simp

lemma xtestbit_sub_sound:
  "bit (x - y - b2z c) n =
      xorb (xorb (bit x n)
              (bit y n)) (sub_borrow_bit x y c n)"
  apply (induction n arbitrary: x y c)
  subgoal for x y c
    apply (simp add: xorb_def b2z_def)
    apply (cases c; cases "bit y 0"; cases "bit x 0"; simp add: bit_0)
    done

  subgoal for n1 x y c
    apply (simp only: bit_Suc)
    apply (subst borrow_bit_rew)
    apply simp

    apply (subgoal_tac "((x - y - b2z c) div 2) = (x div 2 - y div 2 - (b2z (Not (odd x) \<and> odd y) +
      b2z c div 2 + b2z (Not (odd (x - y)) \<and> odd (b2z c))))")
    prefer 2 using sub_shift
     apply simp

    apply (erule ssubst [of "(x - y - b2z c) div 2" _ ])
    apply (simp only: b2z_div2)

    apply (simp only: odd_sub)
    apply (simp only: Zodd_b2z Groups.monoid_add_class.add_0_right)
    apply (subgoal_tac "\<exists> cr. b2z cr = b2z (\<not> odd x \<and> odd y) + b2z (\<not> xorb (odd x) (odd y) \<and> c)")
    prefer 2 using b2z_exist
    apply force

    apply (erule exE)
    subgoal for cr
      using test
      by simp

    done
  done


lemma ztestbit_sub_sound:
  "bit (x - y) n =
      xorb (xorb (bit x n)
              (bit y n)) (sub_borrow_bit x y False n)"
  apply (subgoal_tac "x - y - b2z False = x - y")
  prefer 2 subgoal using b2z_def by simp
  using xtestbit_sub_sound by metis

end