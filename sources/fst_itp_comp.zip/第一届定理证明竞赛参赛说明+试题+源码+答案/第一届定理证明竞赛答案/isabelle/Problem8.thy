theory Problem8
  imports Main "HOL-Hoare.HeapSyntax" (*"~~/src/HOL/Hoare/Hoare_Logic"*)
begin


lemma distpath_null: "distPath h l Ps Null \<Longrightarrow> distPath h l Qs Null \<Longrightarrow> Ps = Qs"
  apply(induct Qs arbitrary: Ps l) apply(simp add: distPath_def)+ by auto

lemma path_sublist: "Path h l Qs (Ref y) \<longrightarrow> Path h l Ps Null \<longrightarrow> (\<exists>Q. Ps = Qs@[y]@Q)"
  apply(induct Qs arbitrary: Ps y l) apply simp by auto

lemma distpath_sublist: "distPath h l Qs (Ref y) \<longrightarrow> distPath h l Ps Null \<longrightarrow> (\<exists>Q. Ps = Qs@[y]@Q) \<and> distinct Ps"
  apply(induct Qs arbitrary: Ps y l) apply(simp add:distPath_def,blast) apply(simp add:distPath_def) by auto

lemma distpath_hd: "distPath h (Ref y) Ps Null \<Longrightarrow> (\<exists>Qs. Ps = y#Qs)"
  apply(induct Ps arbitrary: h y) by (simp add:distPath_def)+

lemma distpath_tl: "distPath h (Ref y) Ps Null \<Longrightarrow> distPath h (h y) (tl Ps) Null"
  apply(induct Ps arbitrary: h y) by (simp add:distPath_def)+

lemma distpath_next: "distPath h l Qs (Ref y) \<Longrightarrow> distinct (Qs@[y]) \<Longrightarrow> distPath h l (Qs@[y]) (h y)"
  by (simp add:distPath_def)


lemma distpath_eq: "distPath h l Ls Null \<Longrightarrow> distPath h l Ps a \<Longrightarrow> distPath h l Qs a \<Longrightarrow> Ps = Qs"
  apply(cases a) using distpath_null apply blast
  using distpath_sublist
  by (metis (no_types, lifting) Cons_eq_appendI List_unique Path_is_List 
        append1_eq_conv distPath_def not_distinct_conv_prefix)

lemma distpath_next2: "distPath h l Ls Null \<Longrightarrow> distPath h l Ps (Ref y) \<Longrightarrow> distPath h l Qs (h y) \<Longrightarrow> Qs = Ps@[y]" 
  using distpath_eq distpath_next
  by (metis Cons_eq_appendI distPath_def distinct.simps(2) distinct1_rotate 
        distpath_sublist not_distinct_conv_prefix rotate1.simps(2)) 

lemma del_one: 
  assumes P: "distPath h l (P@[y]@[ya]@Q) Null"
  shows "distPath (h(y := h ya)) l (P@[y]@Q) Null" 
proof -
  from P have dis: "distinct (P@[y]@[ya]@Q)" by(simp add:distPath_def)
  from P have P': "Path h l (P@[y]@[ya]@Q) Null" by(simp add:distPath_def)
  thm Path_snoc[of h y "h ya" l P]
  from P' have "Path h l P (Ref y)" by simp
  with dis have "Path (h(y := h ya)) l P (Ref y)" by simp
  then have p1: "Path (h(y := h ya)) l (P @ [y]) (h ya)" 
    using Path_snoc[of h y "h ya" l P] by simp
  from P' have "Path h (h ya) Q Null" by simp 
  with dis have p2: "Path (h(y := h ya)) (h ya) Q Null" by simp
  from p1 p2 have "Path (h(y := h ya)) l (P@[y]@Q) Null" by auto
  with dis show ?thesis by(simp add:distPath_def)
qed


abbreviation "K_NO_WAIT :: nat \<equiv> 0" 

(* alloc the first block in free_list *)
lemma mem_alloc01: "VARS free_list nxt slab mem timeout result
  {List nxt (slab^.free_list) Ps}
  IF slab^.free_list \<noteq> Null THEN
    mem := slab^.free_list;
    slab^.free_list := (slab^.free_list)^.nxt;
    result := 0
  ELSE 
    mem := Null;
    IF timeout = K_NO_WAIT THEN
      result := 1
    ELSE
      result := 2
    FI
  FI
  {(Ps \<noteq> [] \<longrightarrow> mem = Ref (hd Ps) \<and> result = 0 \<and> List nxt (slab^.free_list) (tl Ps)) \<and>
    (Ps = [] \<longrightarrow> mem = Null \<and> (result = 1 \<or> result = 2))}"
  apply vcg_simp
  apply fastforce done

(*declare [[show_types]]*)
record block = 
  block_size :: nat
  saddr :: nat

(* allocate the first block, which the block size \<ge> the requested size, in the free_list *)
lemma mem_alloc02: "VARS free_list next mem size result p q
  {distPath next free_list Ps Null}
    IF free_list = Null THEN
      mem := Null;
      result := 0
    ELSE
      IF block_size (addr free_list) \<ge> size THEN
        mem := free_list;
        free_list := free_list^.next;
        result := 1
      ELSE
        q := free_list;
        p := free_list^.next;
        WHILE p \<noteq> Null \<and> block_size (addr p) < size
        INV { distPath next free_list Ps Null \<and> (\<exists>Qs. distPath next free_list Qs p 
              \<and> (\<forall>a. a \<in> set Qs \<longrightarrow> block_size a < size))
              \<and> p = q^.next \<and> (\<exists>Qs. distPath next free_list Qs q \<and> q \<noteq> Null) }
        DO 
          q := p;
          p := p^.next
        OD;
        IF p \<noteq> Null THEN
          mem := p;
          q^.next := p^.next;
          result := 1
        ELSE
          mem := Null;
          result := 0
        FI
      FI
    FI
  {(\<exists>a\<in>set Ps. block_size a \<ge> size) \<longrightarrow> 
      (let b = the (find (\<lambda>x. block_size x \<ge> size) Ps) in  
        mem = Ref b \<and> distPath next free_list (remove1 b Ps) Null) \<and> result = 1}"
  apply vcg_simp

    apply auto[1] apply(simp add:distPath_def) apply(simp add:Let_def) apply(rule conjI)
  using distpath_hd apply fastforce using distpath_hd distpath_tl apply fastforce
     apply(simp add:distPath_def)
     apply (metis Path.simps(1) distinct.simps(2) distinct_singleton linorder_not_less set_ConsD)
    apply(simp add:distPath_def)
  using distinct.simps(1) apply blast

   apply auto[1] 
  subgoal for free_list nexta sizea Qsa Qs q y 
    using distpath_sublist[of nexta free_list Qsa y Ps] distpath_next[of nexta free_list Qsa y] by force

  apply auto[1] using distpath_null apply fastforce
   defer 1 using distpath_null apply fastforce
  apply(simp add:Let_def) apply(rule conjI)
  subgoal for free_list nexta sizea Qsa Qs q y a
  proof -
    assume a1:"distPath nexta free_list Ps Null"
      and a2:"distPath nexta free_list Qsa (Ref y)"
      and a3:"\<forall>a. a \<in> set Qsa \<longrightarrow> block_size a < sizea"
      and a4:"\<not> block_size y < sizea"
    from a1 a2 have "(\<exists>Q. Ps = Qsa @ [y] @ Q) \<and> distinct Ps" using distpath_sublist[of nexta free_list Qsa y Ps] by blast
    then obtain Q where "Ps = Qsa @ [y] @ Q" by blast
    with a3 a4 show "y = the (find (\<lambda>x. sizea \<le> block_size x) Ps)" 
      apply(induct Qsa arbitrary: y Ps) apply simp by fastforce
  qed

  subgoal for free_list nexta sizea Qs Qsa y ya a
  proof -
    assume a1: "distPath nexta free_list Ps Null"
      and a2: "distPath nexta free_list Qsa (Ref y)"
      and a3: "distPath nexta free_list Qs (Ref ya)"
      and a4: "\<forall>a. a \<in> set Qs \<longrightarrow> block_size a < sizea"
      and a5: "\<not> block_size ya < sizea"
      and a6: "nexta y = Ref ya"
    from a1 a2 have p1: "(\<exists>Q. Ps = Qsa @ [y] @ Q) \<and> distinct Ps" using distpath_sublist[of nexta free_list Qsa y Ps] by blast
    then obtain Q where Q: "Ps = Qsa @ [y] @ Q" by blast
    from a2 a3 a1 a6 have QQ: "Qs = Qsa @ [y]" using distpath_next2 by fastforce

    from a1 a2 a6 p1 Q have "distPath nexta free_list (Qsa @ [y]) (Ref ya)" using distpath_next[of nexta free_list Qsa y] by simp
    with a1 have "\<exists>Q. Ps = Qsa @ [y] @ [ya] @ Q" using distpath_sublist[of nexta free_list "Qsa @ [y]" ya Ps] by simp
    then obtain P where P: "Ps = Qsa @ [y] @ [ya] @ P" by blast
    with QQ a4 a5 have ya: "ya = the (find (\<lambda>x. sizea \<le> block_size x) Ps)" apply(induct Qsa arbitrary: y Qs ya Ps) apply simp by auto
    
    with QQ a4 a5 P have "remove1 (the (find (\<lambda>x. sizea \<le> block_size x) Ps)) Ps = Qsa @ [y] @ P"
      by (metis Cons_eq_appendI append_assoc eq_Nil_appendI in_set_conv_decomp remove1_split) 

    with ya P a1 show "distPath (nexta(y := nexta ya)) free_list (remove1 (the (find (\<lambda>x. sizea \<le> block_size x) Ps)) Ps) Null"
      using del_one[of nexta free_list Qsa y ya P] by simp
    
qed
  done

end