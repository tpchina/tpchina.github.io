theory Problem5
  imports Main
begin


consts
  C :: nat
  N :: nat
  caps :: "nat \<Rightarrow> nat"
  vals :: "nat \<Rightarrow> nat"

axiomatization where posN: "N > 0"


definition clear :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> bool option" where
  "clear s i j = (if j = i then None else s j)"

fun val_in_knapsack :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> nat option" where
  "val_in_knapsack s 0 c_rem = Some 0"
| "val_in_knapsack s (Suc n') c_rem = (
    let s' = clear s (Suc n') in
    case s (Suc n') of
      Some True \<Rightarrow> 
        if caps (Suc n') \<le> c_rem then
          (case val_in_knapsack s' n' (c_rem - caps (Suc n')) of
            Some v \<Rightarrow> Some (v + vals (Suc n'))
          | None \<Rightarrow> None)
        else None
    | Some False \<Rightarrow> val_in_knapsack s' n' c_rem
    | None \<Rightarrow> None)"

definition wf :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> bool" where
  "wf s n \<equiv> \<forall>i. (s i \<noteq> None) \<longleftrightarrow> (1 \<le> i \<and> i \<le> n)"

definition opt_s :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> bool" where
  "opt_s s n c_rem \<equiv> 
    wf s n \<and> 
    (\<forall>s' v1 v2. 
      wf s' n \<longrightarrow> 
      val_in_knapsack s' n c_rem = Some v1 \<longrightarrow> 
      val_in_knapsack s n c_rem = Some v2 \<longrightarrow> 
      v1 \<le> v2)"

lemma wf_clr: "1 \<le> n \<Longrightarrow> n \<le> N \<Longrightarrow> wf s n \<Longrightarrow> wf (clear s n) (n - 1)"
  apply (simp add: wf_def clear_def)
  by linarith

definition set_s :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> bool \<Rightarrow> nat \<Rightarrow> bool option" where
  "set_s s i b j = (if j = i then Some b else s j)"

lemma wf_set_s: "
      1 \<le> n \<Longrightarrow> 
      wf s (n - 1) \<Longrightarrow>
      wf (set_s s n b) n"
  apply (simp add: wf_def set_s_def)
  by linarith

lemma clr_set: "
      s n = None \<Longrightarrow>
      clear (\<lambda> j. if j = n then Some True else s j) n = s"
  using clear_def
  by auto

theorem optimal_substructure: "
      1 \<le> n \<Longrightarrow> n \<le> N \<Longrightarrow>
      s n = Some True \<Longrightarrow>
      caps n <= c_rem \<Longrightarrow>
      opt_s s n c_rem \<Longrightarrow>
      opt_s (clear s n) (n - 1) (c_rem - caps n)"
  apply (simp add: opt_s_def)
  apply rule+
  subgoal
    by (metis One_nat_def wf_clr)

  apply (erule conjE)
  apply rule+
  subgoal for s' v1 v2
    apply (subgoal_tac "\<exists>n'. n = Suc n'")
     prefer 2
    subgoal
      by presburger
    apply (erule exE)
    subgoal for n'
    apply (subgoal_tac "val_in_knapsack (set_s s' n True) (Suc n') c_rem = Some (v1 + vals n)")
     prefer 2
      subgoal
        apply (thin_tac  "\<forall>s'. wf s' n \<longrightarrow> (\<forall>v1. val_in_knapsack s' n c_rem = Some v1 \<longrightarrow> (\<forall>v2. val_in_knapsack s n c_rem = Some v2 \<longrightarrow> v1 \<le> v2))")
        apply (simp add: set_s_def)
        apply (subgoal_tac "val_in_knapsack (clear (set_s s' (Suc n') True) (Suc n')) n' (c_rem - caps (Suc n'))
= val_in_knapsack (clear (\<lambda> j. if j = (Suc n') then Some True else s' j) (Suc n')) n' (c_rem - caps (Suc n'))")
        prefer 2
        subgoal
          using set_s_def 
          by presburger
        apply simp
        using clr_set
        by (metis (no_types, lifting) ext wf_def Suc_n_not_le_n option.simps(5))

      apply (subgoal_tac "val_in_knapsack s (Suc n') c_rem = Some (v2 + vals n)")
      subgoal
        by (metis One_nat_def add_le_cancel_right wf_set_s)

      apply (thin_tac  "\<forall>s'. wf s' n \<longrightarrow> (\<forall>v1. val_in_knapsack s' n c_rem = Some v1 \<longrightarrow> (\<forall>v2. val_in_knapsack s n c_rem = Some v2 \<longrightarrow> v1 \<le> v2))")

      apply (simp add: set_s_def)
      done
    done
  done

end