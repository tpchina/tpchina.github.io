theory Problem4
  imports Main
begin

section \<open>Finding local minimum\<close>

definition neighbor_nonequal :: "nat list \<Rightarrow> bool" where
  "neighbor_nonequal xs = (\<forall>i. i < length xs - 1 \<longrightarrow> xs ! i \<noteq> xs ! (i + 1))"

definition is_local_min :: "nat list \<Rightarrow> nat \<Rightarrow> bool" where
  "is_local_min xs i =
  (i \<ge> 0 \<and> i < length xs \<and>
   (i = 0 \<or> xs ! i < xs ! (i - 1)) \<and>
   (i = length xs - 1 \<or> xs ! i < xs ! (i + 1)))"

function local_min :: "nat list \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> nat" where
  "local_min xs left right =
    (if left \<ge> right then left
     else if left + 1 = right then
        if xs ! left < xs ! right then left else right
     else let mid = (left + right) div 2 in
       if xs ! (mid - 1) < xs ! mid then
         local_min xs left (mid - 1)
       else
         local_min xs mid right)"
  by pat_completeness auto
termination by (relation "measure (\<lambda>(xs,l,r). r - l)", auto)
declare local_min.simps [simp del]

definition is_local_min_part :: "nat list \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> bool" where
  "is_local_min_part ls i l r =
   (i \<ge> l \<and> i \<le> r \<and>
    (i = 0 \<or> ls ! i < ls ! (i - 1)) \<and>
    (i = length ls - 1 \<or> ls ! i < ls ! (i + 1)))"

thm  "local_min.induct"

lemma local_min_correct_induct:
  "neighbor_nonequal xs \<Longrightarrow> 0 \<le> a \<Longrightarrow> a \<le> b \<Longrightarrow> b < length xs \<Longrightarrow>
   a = 0 \<or> xs ! a < xs ! (a - 1) \<Longrightarrow>
   b = length xs - 1 \<or> xs ! b < xs ! (b + 1) \<Longrightarrow>
   is_local_min_part xs (local_min xs a b) a b"
proof (induction rule: local_min.induct)
  case (1 xs left right)
  show ?case
  proof (cases "left \<ge> right")
    case True
    then show ?thesis
      using 1(4-8) by (simp add: is_local_min_part_def local_min.simps)
  next
    case False
    note False1 = False
    then show ?thesis
    proof (cases "left + 1 = right")
      case True
      then show ?thesis
        using False1 1(4-8) apply (simp add: is_local_min_part_def local_min.simps)
        by (metis "1.prems"(1) One_nat_def True add_diff_cancel_right' diff_Suc_eq_diff_pred linorder_neqE_nat neighbor_nonequal_def zero_less_diff)
    next
      case False
      note False2 = False
      let ?mid = "(left + right) div 2"
      have a: "left + 2 \<le> right"
        using False1 False2 by simp
      have a2: "(left + right) div 2 \<ge> 1"
        using a by simp
      have b: "left \<le> (left + right) div 2 - 1"
        using a by simp
      have c: "(left + right) div 2 - 1 \<le> right - 1"
        using "1.prems"(3) by linarith
      have d: "(left + right) div 2 - 1 < length xs"
        using c 1(6) by auto
      have d2: "(left + right) div 2 - 1 < length xs - 1"
        using c 1(6)
        using False1 le_diff_conv by auto
      show ?thesis
      proof (cases "xs ! (?mid - 1) < xs ! ?mid")
        case True
        have True2: "xs ! (?mid - 1) < xs ! (?mid - 1 + 1)"
          using True by (metis Nat.le_imp_diff_is_add a2)
        show ?thesis
          apply (subst local_min.simps)
          apply (simp add: Let_def False1 False2 True)
          using 1(1)[of ?mid, OF False1 False2 _ True 1(3-4) b d 1(7)]
          using True2
          by (smt (z3) False2 One_nat_def Suc_eq_plus1 True c diff_le_self is_local_min_part_def le_trans)
      next
        case False
        have "xs ! ((left + right) div 2 - 1) \<noteq> xs ! (((left + right) div 2 - 1 + 1))"
          using 1(3) unfolding neighbor_nonequal_def using d2 a2 by blast
        then have False3: "xs ! ((left + right) div 2 - 1) > xs ! ((left + right) div 2)"
          using False
          by (metis a2 add.commute le_add_diff_inverse linorder_neqE_nat)
        have e: "0 \<le> (left + right) div 2"
          by simp
        have f: "(left + right) div 2 \<le> right"
          using a by linarith
        have f2: "right < length xs"
          using "1.prems"(4) by blast
        show ?thesis
          apply (subst local_min.simps)
          apply (simp add: Let_def False1 False2 False)
          using 1(2)[of ?mid, OF False1 False2 _ False 1(3) e f f2 _ 1(8)]
          using False3
          by (smt (z3) False False2 One_nat_def Suc_eq_plus1 a2 b
              is_local_min_part_def le_add1 le_add_diff_inverse2 le_trans)
        qed
    qed
  qed
qed

theorem local_min_correct:
  assumes "neighbor_nonequal xs"
  assumes "length xs > 0"
  shows "is_local_min xs (local_min xs 0 (length xs - 1))"
proof -
  have 1: "is_local_min_part xs (local_min xs 0 (length xs - 1)) 0 (length xs - 1)"
    using local_min_correct_induct[of xs 0 "length xs - 1"]
    using assms(1) assms(2) by fastforce
  show ?thesis
    using 1
    unfolding is_local_min_def is_local_min_part_def
    by (meson assms(2) diff_less order.strict_trans1 zero_less_one)
qed



end
