theory Problem2
  imports Main
begin

fun prefixes :: "'a list \<Rightarrow> 'a list list" where
  "prefixes [] = [[]]"
| "prefixes (a # l0) = [] # map (\<lambda>xs. a # xs) (prefixes l0)"

lemma nil_in_prefixes: "[] \<in> set (prefixes l)"
  by (induct l) simp_all

theorem in_prefixes: "l1 \<in> set (prefixes (l1 @ l2))"
  apply (induct l1)
  subgoal using nil_in_prefixes by auto
  by simp

theorem in_prefixes_inv: 
  "l1 \<in> set (prefixes l) \<Longrightarrow> \<exists>l2. l1 @ l2 = l"
  apply (induction l arbitrary: l1 rule: prefixes.induct) by auto

fun sublists :: "'a list \<Rightarrow> 'a list list" where
  "sublists [] = [[]]"
| "sublists (a # l0) = map (\<lambda>xs. a # xs) (prefixes l0) @ sublists l0"

lemma sublists_nil: "[] \<in> set (sublists l3)"
  apply (induction l3; simp)
  done

lemma sublists_in_2: "l2 \<in> set (sublists (l2 @ l3))"
  apply (induction l2 arbitrary: l3; simp)
  subgoal for l3
    using sublists_nil by auto
  subgoal for a l2 l3
    apply simp
    using in_prefixes by auto
  done

theorem in_sublists: "l2 \<in> set (sublists (l1 @ l2 @ l3))"
  apply (induction l1 arbitrary: l2 l3)
  subgoal for l2 l3
    apply simp
    using sublists_in_2 by auto
  subgoal for a l1 l2 l3
    apply simp
    done
  done

theorem in_sublists_inv:
  "l2 \<in> set (sublists l) \<Longrightarrow> \<exists>l1 l3. l1 @ l2 @ l3 = l"
  apply (induction l arbitrary: l2; simp)
  subgoal for a l l2
    by (metis append_Cons append_Nil in_prefixes_inv list.set_intros(2) list.set_map prefixes.simps(2))
  done


end