From Coq Require Import List Lia FunctionalExtensionality.
Import ListNotations.

Section ProblemB.

  Parameter C: nat. 
  Parameter N: nat. 

  Hypothesis posN: N > 0.

  Parameter caps: nat -> nat.
  Parameter vals: nat -> nat. 

  Definition clear (s: nat -> option bool) i :=
    fun j => if Nat.eqb j i then None else s j. 

  Fixpoint val_in_knapsack (s: nat -> option bool) (n: nat) (c_rem: nat) : option nat := 
    match n with 
      0 => Some 0 
    | S n' => 
      let s' := clear s n in 
        match s n with 
          Some true => 
            if Nat.leb (caps n) c_rem then 
              match (val_in_knapsack s' n' (c_rem - (caps n))) with 
                Some v => Some (v + vals n)
              | _ => None
              end
            else 
              None 
        | Some false => 
            val_in_knapsack s' n' c_rem 
        | None => None
        end 
    end. 

  Definition wf (s: nat -> option bool) (n: nat) :=
    forall i, s i <> None <-> 1 <= i <= n. 


  Definition opt_s (s: nat -> option bool) n c_rem :=
    wf s n /\
      forall s' v1 v2,
        wf s' n ->
        val_in_knapsack s' n c_rem = Some v1 ->
        val_in_knapsack s n c_rem = Some v2 ->
        v1 <= v2.

  Lemma wf_clr:
    forall s n,
      1 <= n <= N -> wf s n -> wf (clear s n) (n - 1). 
  Proof.
    intros s n Hlt Hwf.
    unfold wf in *.
    split.
    -
      intros Hclr.
      unfold clear in Hclr.
      destruct (Nat.eqb i n) eqn: E.
      exfalso. apply Hclr. auto.
      apply Hwf in Hclr.
      apply PeanoNat.Nat.eqb_neq in E.
      lia.
    -
      intros Hrgn.
      assert (1 <= i <= n) by lia.
      apply Hwf in H.
      intros Hclr.
      apply H.
      unfold clear in Hclr.
      destruct (Nat.eqb i n) eqn: E.
      rewrite PeanoNat.Nat.eqb_eq in E. 
      lia.
      auto.
  Qed.  

  Definition set_s (s: nat -> option bool) i b :=
    fun j => if Nat.eqb j i then Some b else s j. 

  Lemma wf_set_s: 
    forall s n b, 
      1 <= n -> 
      wf s (n - 1) ->
      wf (set_s s n b) n.
  Proof.
    intros s n b Hge Hwf.
    unfold wf in *.
    intros.
    specialize (Hwf i).
    destruct Hwf as (Hlr & Hrl).
    split.
    - intros Hs.
      destruct (s i) eqn: E.
      + assert (Heq: Some b0 <> None).
        { intro HF. inversion HF. }
        specialize (Hlr Heq).
        lia.
      +
        unfold set_s in Hs.
        destruct (Nat.eqb i n) eqn: E_.
        * apply PeanoNat.Nat.eqb_eq in E_.
          subst.
          lia.
        * exfalso.
          apply Hs; auto.
    - intros Hrgn.
      assert (Hor: i = n \/ 1 <= i <= n - 1) by lia.
      destruct Hor as [Heq | Hle].
      + 
        subst.
        unfold set_s.
        rewrite PeanoNat.Nat.eqb_refl.
        intros Hf.
        inversion Hf. 
      +
        specialize (Hrl Hle).
        intros Hn.
        apply Hrl.
        unfold set_s in Hn.
        destruct (Nat.eqb i n) eqn: E; auto.
        inversion Hn.
  Qed.   


  Lemma clr_set:
    forall s n,
      s n = None -> 
      clear (fun j : nat => if Nat.eqb j n then Some true else s j) n = s.
  Proof.
    intros s n Hn.
    unfold clear.
    apply functional_extensionality.
    intro.
    destruct (Nat.eqb x n) eqn: E.
    rewrite PeanoNat.Nat.eqb_eq in E.
    subst.
    eauto.
    auto.
  Qed. 

  Theorem optimal_substructure:
    forall s n c_rem,
      1 <= n <= N ->
      s n = Some true ->
      caps n <= c_rem -> 
      opt_s s n c_rem ->
      opt_s (clear s n) (n - 1) (c_rem - caps n).
  Proof.
    intros s n c_rem Hrgn Htt Hrem Hopt.
    unfold opt_s in *.
    destruct Hopt as (Hwf & Ha).
    split.
    - apply wf_clr; auto.
    - intros s' v1 v2 Hwf' Hval1 Hval2.
      assert (Hor: v1 <= v2 \/ v1 > v2) by lia.
      destruct Hor; auto.
      exfalso.
      unfold wf in Hwf.
      assert (Hnone: s' n = None).
      {
        unfold wf in Hwf'.
        specialize (Hwf' n).
        destruct (s' n) eqn: E; auto.
        destruct Hwf'.
        assert (Heq: Some b <> None).
        { intro HF. inversion HF. }
        specialize (H0 Heq).
        lia.
      }      
      assert (Hex: exists n', n = S n').
      { destruct n. exfalso. lia. eexists; eauto. }  
      assert (Hv1: val_in_knapsack (set_s s' n true) n c_rem = Some (v1 + vals n)).
      {
        destruct Hex; subst. 
        simpl.
        unfold set_s.
        rewrite PeanoNat.Nat.eqb_refl.
        setoid_rewrite <- PeanoNat.Nat.leb_le in Hrem.
        rewrite Hrem.
        rewrite clr_set; auto.
        assert (Heq: S x - 1 = x).
        { lia. }
        rewrite Heq in Hval1.  
        rewrite Hval1. 
        auto.
      }
      assert (Hv2: val_in_knapsack s n c_rem = Some (v2 + vals n)).
      {
        destruct Hex; subst. 
        simpl.
        rewrite Htt.
        setoid_rewrite <- PeanoNat.Nat.leb_le in Hrem.
        rewrite Hrem.
        assert (Heq: S x - 1 = x).
        { lia. }
        rewrite Heq in Hval2.  
        rewrite Hval2.
        auto.
      }
      assert (Heq: wf (set_s s' n true) n).
      {
        eapply wf_set_s; eauto. lia.
      }
      specialize (Ha (set_s s' n true) _ _ Heq Hv1 Hv2).
      lia.
  Qed. 
  
End ProblemB.