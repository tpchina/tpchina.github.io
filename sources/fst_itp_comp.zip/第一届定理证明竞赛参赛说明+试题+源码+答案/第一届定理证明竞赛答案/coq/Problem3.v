From Coq Require Import List Lia.
Import ListNotations.

Inductive tree (A : Type) : Type :=
| Leaf : tree A
| Node : A -> tree A -> tree A -> tree A.

Arguments Leaf {A}.
Arguments Node {A} _ _ _.

Fixpoint mirror {A : Type} (t : tree A) : tree A :=
  match t with
  | Leaf => Leaf
  | Node x l r => Node x (mirror r) (mirror l)
  end.

Definition is_symmetric {A : Type} (t : tree A) : Prop :=
  t = mirror t.

Fixpoint check_mirror {A : Type} (t1 t2 : tree A) : Prop :=
  match t1, t2 with
  | Leaf, Leaf => True
  | Node x1 l1 r1, Node x2 l2 r2 =>
    (x1 = x2) /\ (check_mirror l1 r2) /\ (check_mirror r1 l2)
  | _, _ => False
  end.

Definition check_symmetric {A : Type} (t : tree A) : Prop :=
  match t with
  | Leaf => True
  | Node x l r => check_mirror l r
  end.

Lemma check_mirror_correct : forall {A : Type} (t1 t2 : tree A),
  check_mirror t1 t2 <-> t1 = mirror t2.
Proof.
  induction t1; simpl; intros.
  - split; intros.
    + destruct t2; simpl.
      auto.
      inversion H.
    + destruct t2; simpl.
      auto.
      simpl in H.
      inversion H.
  - split; destruct t2; simpl; intros; auto.
    + inversion H.
    + destruct H as (Ha_eq & Ht1_eq & Ht2_eq).
      subst a0.
      f_equal.
      * specialize (IHt1_1 t2_2).
        intuition.
      * specialize (IHt1_2 t2_1).
        intuition.
    + inversion H.
    + inversion H.
      split; auto.
      specialize (IHt1_1 t2_2).
      specialize (IHt1_2 t2_1).
      split; intuition.
      * subst t1_1.
        auto.
      * subst t1_2.
        auto.
Qed.

Lemma mirror_mirror_eq: forall {A : Type} (t2: tree A),
  t2 = mirror (mirror t2).
Proof.
  induction t2; simpl; intros; auto.
  f_equal; auto.
Qed.

Theorem check_symmetric_correct: forall {A : Type} (t: tree A),
  check_symmetric t <-> is_symmetric t.
Proof.
  unfold is_symmetric.
  induction t; simpl; split; intros; auto.
  - rewrite check_mirror_correct in H.
    subst t1.
    f_equal.
    apply mirror_mirror_eq.
  - inversion H.
    rewrite <- H2.
    rewrite check_mirror_correct.
    auto.
Qed.