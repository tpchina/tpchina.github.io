From Coq Require Import List Lia.

Definition Tick (A: Type): Type := (A * nat)%type.

Definition ret {A: Type} (a: A): Tick A := (a, 0).

Definition bind {A B: Type} (f: Tick A) (g: A -> Tick B): Tick B :=
  let (r1, c1) := f in
  let (r2, c2) := g r1 in (r2, c1 + c2).

Definition tick (n: nat): Tick unit := (tt, n).

Declare Scope monad_scope.
Delimit Scope monad_scope with monad.
Notation "x <- c1 ;; c2" := (bind c1 (fun x => c2))
  (at level 61, c1 at next level, right associativity) : monad_scope.
Notation " x : T <- c1 ;; c2" :=(bind c1 (fun x : T => c2))
  (at level 61, c1 at next level, right associativity) : monad_scope.
Notation "' pat <- c1 ;; c2" :=
  (bind c1 (fun x => match x with pat => c2 end))
  (at level 61, pat pattern, c1 at next level, right associativity) : monad_scope.
Notation "e1 ;; e2" := (bind e1 (fun _: unit => e2))
  (at level 61, right associativity) : monad_scope.
Local Open Scope monad.

Record queue (A: Type): Type :=
{
    inq: list A;
    outq: list A;
}.

Arguments inq {A} (_).
Arguments outq {A} (_).

Definition queue_empty (A: Type): Tick (queue A) :=
  ret {| inq := nil; outq := nil |}.

Fixpoint rev_app {A: Type} (l1 l2: list A): Tick (list A) :=
  match l1 with
  | nil =>    ret l2
  | h :: t => tick 1;;
              rev_app t (h :: l2)
  end.

Definition queue_in_to_out {A: Type} (q: queue A): Tick (queue A) :=
  r <- rev_app q.(inq) q.(outq);;
  ret {| inq := nil; outq := r |}.

Definition queue_enq {A: Type} (q: queue A) (x: A): Tick (queue A) :=
  tick 1;;
  ret {| inq := x :: q.(inq); outq := q.(outq) |}.

Definition queue_deq {A: Type} (q: queue A): Tick (option A * queue A) :=
  tick 1;;
  match q.(outq) with
  | h :: t => ret (Some h, {| inq := q.(inq); outq := t |})
  | nil    => q' <- queue_in_to_out q;;
              match q'.(outq) with
              | nil => ret (None, q')
              | h :: t => ret (Some h, {| inq := nil; outq := t |})
              end
  end.

Fixpoint seq_op_queue {A: Type} (q: queue A) (ops: list (option A)):
  Tick (queue A) :=
  match ops with
  | nil => ret q
  | op :: ops' =>
      match op with
      | Some x =>
          q' <- queue_enq q x;;
          seq_op_queue q' ops'
      | None =>
          '(_, q') <- queue_deq q;;
          seq_op_queue q' ops'
      end
  end.

Definition seq_op_queue_from_empty {A: Type} (ops: list (option A)):
  Tick (queue A):=
  q <- queue_empty A;;
  seq_op_queue q ops.

Lemma tick_bind_res {A: Type}: forall n (f: Tick A),
  fst (tick n;; f) = fst f.
Proof.
  destruct f; reflexivity.
Qed.

Lemma bind_cost {A B: Type}: forall (f: Tick A) (g: A -> Tick B),
  snd (bind f g) = snd f + snd (g (fst f)). 
Proof.
  intros.
  unfold bind; destruct f; simpl.
  destruct (g a); simpl.
  reflexivity.
Qed.

Lemma rev_app_cost {A: Type}: forall (l1 l2: list A),
  snd (rev_app l1 l2) = length l1.
Proof.
  intros.
  revert l2; induction l1; simpl; intros.
  + reflexivity.
  + pose proof IHl1 (a :: l2).
    destruct(rev_app l1 (a :: l2)).
    simpl in *.
    lia.
Qed.

Lemma queue_in_to_out_cost {A: Type}: forall (q: queue A),
  snd (queue_in_to_out q) = length q.(inq).
Proof.
  intros.
  unfold queue_in_to_out; destruct q as [i o]; simpl.
  rewrite bind_cost; simpl.
  rewrite rev_app_cost.
  lia.
Qed.

Lemma queue_in_to_out_res_inq {A: Type}: forall (q: queue A),
  (fst (queue_in_to_out q)).(inq) = nil.
Proof.
  intros.
  unfold queue_in_to_out.
  unfold bind; simpl.
  destruct (rev_app (inq q) (outq q)); simpl.
  reflexivity.
Qed.

Lemma queue_deq_cost {A: Type}: forall (q: queue A) res q',
  fst (queue_deq q) = (res, q') ->
  length q'.(inq) + snd (queue_deq q) <= 1 + length q.(inq).
Proof.
  intros.
  destruct q as [i o]; simpl in *.
  unfold queue_deq in *; simpl outq in *.
  rewrite bind_cost.
  rewrite tick_bind_res in H.
  destruct o.
  + rewrite bind_cost.
    rewrite queue_in_to_out_cost.
    pose proof queue_in_to_out_res_inq {| inq := i; outq := nil |}.
    unfold bind in H.
    destruct (queue_in_to_out {| inq := i; outq := nil |}); simpl in *.
    destruct q.(outq); simpl in *.
    - injection H as ? ?.
      rewrite <- H1, H0.
      simpl.
      lia.
    - injection H as ? ?.
      rewrite <- H1.
      simpl.
      lia.
  + simpl in *.
    injection H as ? ?.
    rewrite <- H0.
    simpl.
    lia.
Qed.

Lemma seq_op_queue_cost {A: Type}: forall (q: queue A) ops,
  snd (seq_op_queue q ops) <= length q.(inq) + 2 * (length ops).
Proof.
  intros.
  revert q; induction ops; simpl; intros.
  + lia.
  + destruct a.
    - pose proof IHops {| inq := a :: inq q; outq := outq q |}.
      destruct ((seq_op_queue {| inq := a :: inq q; outq := outq q |} ops)).
      simpl in *.
      lia.
    - rewrite bind_cost.
      destruct (fst (queue_deq q)) as [? ?] eqn:HH.
      pose proof queue_deq_cost q _ _ HH.
      pose proof IHops q0.
      lia.
Qed.


Theorem seq_op_queue_from_empty_cost {A: Type} (ops: list (option A)):
  snd (seq_op_queue_from_empty ops) <= 2 * (length ops).
Proof.
  intros.
  unfold seq_op_queue_from_empty.
  rewrite bind_cost.
  pose proof seq_op_queue_cost (fst (queue_empty A)) ops.
  simpl in *.
  lia.
Qed.
