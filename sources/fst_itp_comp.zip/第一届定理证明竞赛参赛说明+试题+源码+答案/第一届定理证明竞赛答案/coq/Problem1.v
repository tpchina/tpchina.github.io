From Coq Require Import List Lia.
Import ListNotations.
Section ProblemA. 
          
Parameter P: nat -> Prop.
Parameter Q: nat -> Prop.
Parameter R: nat -> nat -> Prop. 

Inductive A : nat -> Prop :=
  ca0: forall n, P n -> A n
| ca1: forall n1, (forall n2, R n1 n2 -> B n2) -> A n1
with B: nat -> Prop :=
  cb0: forall n, Q n -> B n
| cb1: forall n1 n2, R n1 n2 -> A n2 -> B n1. 

Scheme a_ind := Induction for A Sort Prop 
  with b_ind := Induction for B Sort Prop.

Theorem neg_a:
  (forall n, ~P n /\ ~Q n) ->
  (forall n1, exists n2, R n1 n2) -> 
  (forall n, A n -> False).  
Proof.
  intros Hpq Hr.
  pose proof a_ind as H1.
  specialize (H1 (fun n (_: A n) => False) (fun n (_: B n) => False)).
  simpl in H1.
  eapply H1; eauto. clear H1.
  - intros n Hpn. 
    destruct (Hpq n). 
    apply H; eauto.
  - intros. 
    destruct (Hr n1). 
    eapply H; eauto.
  - intros. 
    destruct (Hpq n). 
    tauto.
Qed.

End ProblemA.