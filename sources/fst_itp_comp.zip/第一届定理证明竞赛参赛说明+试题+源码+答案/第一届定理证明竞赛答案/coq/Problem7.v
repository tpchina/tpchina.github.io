From Coq Require Import ZArith Bool Lia.
Open Scope Z_scope.

Check Z.testbit.

(* 下面的Z相关Lemma在证明过程中可能会被用到： 5个标准库中lemma和 3个自定义lemma *)
Check Z.bit0_odd.
Check Z.bit0_mod.
Check Z_div_mod_eq_full.
Check Zodd_mod.
Check Z.testbit_succ_r.
Check Z.odd_sub.

Lemma Zodd_b2z : forall b, Z.odd (Z.b2z b) = b.
Proof.
  destruct b; reflexivity.
Qed.

Lemma decomp : forall x,
    (x = 2 * (x / 2) + Z.b2z (Z.odd x))%Z.
Proof.
  intros.
  rewrite <- Z.bit0_odd.
  rewrite Z.bit0_mod.
  apply Z_div_mod_eq_full.
Qed.

Ltac Zify.zify_convert_to_euclidean_division_equations_flag ::= constr:(true).

Lemma b2z_div2 : forall b,
    (Z.b2z b / 2 = 0)%Z.
Proof.
  destruct b; reflexivity.
Qed.

Lemma b2z_exists: forall x y c0, 
  exists cr,
  Z.b2z (negb (Z.odd x) && Z.odd y) +
  Z.b2z (negb (xorb (Z.odd x) (Z.odd y)) && c0) = Z.b2z cr.
Proof.
  intros.
  destruct (Z.odd x),(Z.odd y),c0; simpl;
    try (exists true;  reflexivity);
    try (exists false;  reflexivity).
Qed.


Fixpoint sub_borrow_bit (x y : Z) (c:bool) (n:nat) :=
  match n with
  | O => c
  | S n' =>
      let pc := sub_borrow_bit x y c n' in
      let n := Z.of_nat n' in
                  (orb
                    (andb (negb (Z.testbit x n))
                          (Z.testbit y  n)) (**r x[n] = 0 /\ y[n] = 1*)
                      (andb pc (negb (xorb (Z.testbit x n) (Z.testbit y n)))))  (**r x[n] = y[n] *)
  end.

Lemma borrow_bit_rew : forall  (x y : Z) (c:bool) (n:nat),
    sub_borrow_bit x y c n =
  match n with
  | O => c
  | S n' =>
      let pc := sub_borrow_bit x y c n' in
      let n := Z.of_nat n' in
                  (orb (andb (negb (Z.testbit x n))
                          (Z.testbit y  n))
                      (andb pc (negb (xorb (Z.testbit x n) (Z.testbit y n)))))
  end.
Proof.
  destruct n; try reflexivity.
Qed.

Lemma sub_shift : forall a b,
    ((a - b) / 2 =
        (a / 2 - (b / 2) - (Z.b2z (negb (Z.odd a) && Z.odd b))))%Z.
Proof.
  intros.
  rewrite! Zodd_mod.
  destruct (negb (Zeq_bool (a mod 2) 1) && Zeq_bool (b mod 2) 1) eqn:LB.
  - simpl.
    rewrite andb_true_iff in LB.
    destruct LB as (LB1 & LB2).
    rewrite negb_true_iff in LB1.
    apply Zeq_bool_neq in LB1.
    apply Zeq_bool_eq in LB2.
    lia.
  - simpl.
    rewrite andb_false_iff  in LB.
    destruct LB.
    rewrite negb_false_iff in H.
    apply Zeq_bool_eq in H.
    lia.
    apply Zeq_bool_neq in H.
    lia.
Qed.

Lemma sub_borrow_bit_eq: forall n x y cr c0
  (CR: Z.b2z (negb (Z.odd x) && Z.odd y) + Z.b2z (negb (xorb (Z.odd x) (Z.odd y)) && c0) = Z.b2z cr),
    sub_borrow_bit (x / 2) (y / 2) cr n =
    negb (Z.testbit x (Z.of_nat n)) && Z.testbit y (Z.of_nat n)
    || sub_borrow_bit x y c0 n && negb (xorb (Z.testbit x (Z.of_nat n)) (Z.testbit y (Z.of_nat n))).
Proof.
  induction n.
  {
    simpl.
    intros.
    destruct cr,(Z.odd x),(Z.odd y),c0; simpl in *; try reflexivity;
      try congruence.
  }
  {
    intros.
    rewrite borrow_bit_rew.
    cbv zeta.
    
    apply IHn in CR.
    rewrite CR.

    replace (Z.of_nat (S n)) with (Z.succ (Z.of_nat n)) by lia.
    replace (Z.testbit x (Z.succ (Z.of_nat n))) with (Z.testbit (x/2) (Z.of_nat n)).
    replace (Z.testbit y (Z.succ (Z.of_nat n))) with (Z.testbit (y/2) (Z.of_nat n)).
    reflexivity.
    rewrite (decomp y) at 2.
    rewrite Z.testbit_succ_r. reflexivity. lia.
    rewrite (decomp x) at 2.
    rewrite Z.testbit_succ_r. reflexivity. lia.
  }
Qed.

Lemma xtestbit_sub_sound : forall n x y c0,
    Z.testbit (x - y - Z.b2z c0) (Z.of_nat n) =
      xorb (xorb (Z.testbit x (Z.of_nat n))
              (Z.testbit y (Z.of_nat n))) (sub_borrow_bit x y c0 n).
Proof.
  induction n.
  - simpl.
    intros.
    rewrite! Z.odd_sub.
    rewrite Zodd_b2z.
    reflexivity.
  -
    intros.
    rewrite (decomp (x - y - Z.b2z c0)) at 1.
    replace (Z.of_nat (S n)) with (Z.succ (Z.of_nat n)) at 1 by lia.
    rewrite Z.testbit_succ_r by lia.
    replace (Z.of_nat (S n)) with (Z.succ (Z.of_nat n)) by lia.
    rewrite borrow_bit_rew.
    cbv zeta.
    rewrite (decomp x) at 2.
    rewrite (decomp y) at 2.
    rewrite! Z.testbit_succ_r by lia.

    rewrite sub_shift.
    rewrite sub_shift.
    rewrite b2z_div2.
    rewrite Z.odd_sub.
    rewrite! Zodd_b2z.

    pose proof (b2z_exists x y c0) as CR.
    destruct CR as (cr& CR).

    replace ((x / 2 - y / 2 - Z.b2z (negb (Z.odd x) && Z.odd y) - 0 -
      Z.b2z (negb (xorb (Z.odd x) (Z.odd y)) && c0)))
      with  (x / 2 - y / 2 - Z.b2z cr)%Z by lia.
    rewrite IHn.
    f_equal.
    clear IHn.
    apply sub_borrow_bit_eq; auto.
Qed.

Lemma testbit_sub_sound : forall n x y,
    Z.testbit (x - y) (Z.of_nat n) =
      xorb (xorb (Z.testbit x (Z.of_nat n))
              (Z.testbit y (Z.of_nat n))) (sub_borrow_bit x y false n).
Proof.
  intros.
  rewrite <- xtestbit_sub_sound.
  f_equal. simpl; ring.
Qed.