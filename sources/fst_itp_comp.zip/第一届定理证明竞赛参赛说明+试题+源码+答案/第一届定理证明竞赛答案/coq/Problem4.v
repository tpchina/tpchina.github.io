From Coq Require Import Arith List Lia.

Definition neighbor_nonequal (xs : list nat) : Prop :=
  forall i, i < length xs - 1 -> nth i xs 0 <> nth (i + 1) xs 0.

Definition is_local_min (xs : list nat) (i : nat) : Prop :=
  i < length xs /\
  (i = 0 \/ nth i xs 0 < nth (i - 1) xs 0) /\
  (i = length xs - 1 \/ nth i xs 0 < nth (i + 1) xs 0).

Lemma ge_exists:
 forall  right left (g : right > left)
  (n : left + 1 <> right),
  exists n0 : nat, right = n0 + left /\ n0 > 1.
Proof.
  induction right; simpl; intros.
  - inversion g.
  - destruct left.
    + exists (S right).
      lia.
    + specialize (IHright left).
      apply Arith_base.gt_S_n_stt in g.
      rewrite plus_Sn_m in n.
      rewrite Nat.succ_inj_wd_neg in n.
      specialize (IHright g n).
      destruct IHright as (k & Hk1 & Hk2).
      exists k.
      lia.
Qed.

Lemma div2_plus_2n: forall n k, Nat.div2 (k + (n + n)) = Nat.div2 k + n.
Proof.
  induction n; simpl; intros.
  - rewrite ! Nat.add_0_r.
    lia.
  - specialize (IHn (S (S k))).
    replace (S (S k) + (n + n)) with (k + S (n + S n))  in IHn by lia.
    rewrite IHn.
    simpl.
    lia.
Qed.

Lemma div2_le: forall n k,
  n <= k -> Nat.div2 n <= Nat.div2 k.
Proof.
  intros.
  pose proof (Nat.Div0.div_le_mono n k 2) as Heq.
  rewrite ! Nat.div2_div.
  apply Heq.
  lia.
Qed.

Inductive local_min : forall (xs : list nat) (l r i: nat), Prop :=
  | case_le_right_left : forall xs l r,
      r <= l -> 
      local_min xs l r l
  | case_left_plus_1_eq_right_l: forall xs l r,
      l < r -> 
      r = l+1 ->
      nth l xs 0 < nth r xs 0 ->
      local_min xs l r l
  | case_left_plus_1_eq_right_r: forall xs l r,
      l < r -> 
      r = l+1 ->
      nth r xs 0 <= nth l xs 0 ->
      local_min xs l r r
  | case_mid_1: forall xs l r mid i,
      l < r -> 
      l+1 <> r ->
      mid = Nat.div2 (l + r) ->
      nth (mid - 1) xs 0 < nth mid xs 0 ->
      local_min xs l (mid - 1) i ->
      local_min xs l r i
  | case_mid_r: forall xs l r mid i,
      l < r -> 
      l+1 <> r ->
      mid = Nat.div2 (l + r) ->
      nth mid xs 0 <= nth (mid - 1) xs 0 ->
      local_min xs mid r i ->
      local_min xs l r i
.

Definition is_local_min_part (ls : list nat) (l r i: nat) : Prop :=
  i >= l /\ i <= r /\
  (i = 0 \/ (i < length ls /\ (i-1) < length ls /\ nth i ls 0 < nth (i-1) ls 0)) /\
  (i = length ls - 1 \/ (i < length ls /\ (i+1) < length ls /\ nth i ls 0 < nth (i+1) ls 0)).

Lemma local_min_correct_induct :
  forall xs a b i,
    neighbor_nonequal xs ->
    0 <= a -> a <= b -> b < length xs ->
    (a = 0 \/ (a < length xs /\ (a-1) < length xs /\ nth a xs 0 < nth (a-1) xs 0)) ->
    (b = length xs - 1 \/ (b < length xs /\ (b+1) < length xs /\ nth b xs 0 < nth (b+1) xs 0)) ->
    local_min xs a b i ->
    is_local_min_part xs a b i.
Proof.
  intros xs l r i H_neighbor H_a_lower H_ab H_b_upper H_a_cond H_b_cond Hi.
  unfold is_local_min_part.
  induction Hi; try lia.
  - assert (Heq: l = r) by lia.
    subst l.
    lia.

  - subst r.
    split. lia.
    split. lia.
    split. lia.
    destruct H_b_cond as [Hb | Hb].
    lia.
    lia.

  - subst r.
    split. lia.
    split. lia.
    split.
    + destruct H_a_cond as [Hb | (Hb & Hc & Hd)].
      * subst l.
        simpl in *.
        right.
        split. lia.
        split. lia.
        rewrite Nat.lt_eq_cases in H1.
        destruct H1 as [H1 | H1].
        lia.
        unfold neighbor_nonequal in *.
        exfalso.
        eapply H_neighbor with (i := 0); eauto.
        lia.
      * right.
        split. lia.
        split. lia.
        rewrite Nat.add_sub.
        rewrite Nat.lt_eq_cases in H1.
        destruct H1 as [H1 | H1].
        lia.
        unfold neighbor_nonequal in *.
        exfalso.
        eapply H_neighbor with (i := l); eauto.
        lia.
    + destruct H_b_cond as [Hb | Hb].
      lia.
      lia.
  - specialize (IHHi H_neighbor H_a_lower).
    assert (Heq: l <= mid - 1).
    {
      subst mid.
      clear - H H0.
      pose proof (ge_exists _ _ H H0) as Heq.
      destruct Heq as (k & Hk & Hk1).
      subst r.
      rewrite PeanoNat.Nat.add_shuffle3.
      rewrite div2_plus_2n.
      rewrite Nat.add_sub_swap.
      - replace 1 with (Nat.div2 2). 2:{ simpl. auto. }
        assert (Heq: 2 <= k) by lia.
        apply div2_le in Heq.
        lia.
      - replace 1 with (Nat.div2 2). 2:{ simpl. auto. }
        assert (Heq: 2 <= k) by lia.
        apply div2_le in Heq.
        lia.
    }
    specialize (IHHi Heq); clear Heq.

    assert (Heq: mid - 1 < length xs). {
      subst mid.
      clear - H H0 H_b_upper.
      pose proof (ge_exists _ _ H H0) as Heq.
      destruct Heq as (k & Hk & Hk1).
      subst r.
      rewrite PeanoNat.Nat.add_shuffle3.
      rewrite div2_plus_2n.
      rewrite Nat.add_sub_swap.
      - assert (Heq: Nat.div2 k <= k). 2:{ lia. }
        apply Nat.div2_decr.
        lia.
      - replace 1 with (Nat.div2 2). 2:{ simpl. auto. }
        assert (Heq: 2 <= k) by lia.
        apply div2_le in Heq.
        lia.
    }
    specialize (IHHi Heq); clear Heq.

    assert (Heq: l = 0 \/
      l < length xs /\
      l - 1 < length xs /\ nth l xs 0 < nth (l - 1) xs 0) by lia.
    specialize (IHHi Heq); clear Heq.

    assert (Heq: mid - 1 = length xs - 1 \/
mid - 1 < length xs /\
mid - 1 + 1 < length xs /\
nth (mid - 1) xs 0 < nth (mid - 1 + 1) xs 0). {
      subst mid.
      clear - H H0 H_b_upper H2.
      assert (Heq: Nat.div2 (l + r) = length xs \/ 
      Nat.div2 (l + r) <> length xs) by lia.
      destruct Heq as [He | He].
      lia.
      right.
      rewrite ! Nat.sub_add.
      2:{ 
        pose proof (ge_exists _ _ H H0) as Heq.
        destruct Heq as (k & Hk & Hk1).
        subst r. 
        rewrite PeanoNat.Nat.add_shuffle3.
        rewrite div2_plus_2n.
        replace 1 with (Nat.div2 2). 2:{ simpl. auto. }
        assert (Heq: 2 <= k) by lia.
        apply div2_le in Heq.
        lia.
      }

      assert (Heq: Nat.div2 (l + r) < length xs).
      2:{
        split; [| split; [| auto]]; lia.
      }
      pose proof (ge_exists _ _ H H0) as Heq.
      destruct Heq as (k & Hk & Hk1).
      subst r. 
      rewrite PeanoNat.Nat.add_shuffle3.
      rewrite div2_plus_2n.
      assert (Heq: Nat.div2 k <= k). 2:{ lia. }
      apply Nat.div2_decr.
      lia.
    }
    specialize (IHHi Heq); clear Heq.
    destruct IHHi as (Heq1 & Heq2 & Heq); try lia.
    split; try lia.
    split; try lia.
    subst mid.
    clear - Heq1 Heq2 H H0.
    pose proof (ge_exists _ _ H H0) as Heq.
    destruct Heq as (k & Hk & Hk1).
    subst r. 
    rewrite PeanoNat.Nat.add_shuffle3 in Heq2.
    rewrite div2_plus_2n in Heq2.
    assert (Heq: Nat.div2 k <= k). 2:{ lia. }
    apply Nat.div2_decr.
    lia.

  - specialize (IHHi H_neighbor).
    assert (Heq: 0 <= mid) by lia.
    specialize (IHHi Heq); clear Heq.
    assert (Heq: mid <= r). {
      subst mid.
      clear - H H0.
      pose proof (ge_exists _ _ H H0) as Heq.
      destruct Heq as (k & Hk & Hk1).
      subst r. 
      rewrite PeanoNat.Nat.add_shuffle3.
      rewrite div2_plus_2n.
      assert (Heq: Nat.div2 k <= k). 2:{ lia. }
      apply Nat.div2_decr.
      lia.
    }
    specialize (IHHi Heq H_b_upper); clear Heq.

    assert (Heq: mid = 0 \/
mid < length xs /\
mid - 1 < length xs /\ nth mid xs 0 < nth (mid - 1) xs 0 ). {
        subst mid.
        clear - H H0 H_b_upper H2 H_neighbor.
        destruct (Nat.div2 (l + r)) eqn: Hm.
        lia.
        right.
        simpl in *.
        rewrite Nat.sub_0_r in *.
        pose proof (ge_exists _ _ H H0) as Heq.
        destruct Heq as (k & Hk & Hk1).
        subst r. 
        rewrite PeanoNat.Nat.add_shuffle3 in Hm.
        rewrite div2_plus_2n in Hm.
        rewrite <- Hm in *.
        split.
        - assert (Heq: Nat.div2 k <= k). 2:{ lia. }
          apply Nat.div2_decr.
          lia.
        - split.
          + assert (Heq: Nat.div2 k <= k). 2:{ lia. }
            apply Nat.div2_decr.
            lia.
          + assert (Heq: nth n xs 0 <> nth (Nat.div2 k + l) xs 0 ). 2:{ lia. }
            unfold neighbor_nonequal in H_neighbor.
            rewrite Hm.
            rewrite <- Nat.add_1_r.
            apply H_neighbor.
            assert (Heq: Nat.div2 k <= k). 2:{ lia. }
            apply Nat.div2_decr.
            lia.
    }
    specialize (IHHi Heq H_b_cond); clear Heq.

    destruct IHHi as (Heq1& Heq2 & Heq); try lia.
    split; try lia.
    subst mid.
    clear - Heq1 Heq2 H H0.
    pose proof (ge_exists _ _ H H0) as Heq.
    destruct Heq as (k & Hk & Hk1).
    subst r. 
    rewrite PeanoNat.Nat.add_shuffle3 in Heq1.
    rewrite div2_plus_2n in Heq1.
    assert (Heq: Nat.div2 0 <= Nat.div2 k). 2:{ simpl in Heq. lia. }
    apply div2_le. (*)
    Search (_ <= Nat.div2 _).
    apply Nat.div2_decr. *)
    lia.
Qed.

Theorem local_min_correct:
  forall xs i,
    neighbor_nonequal xs ->
    length xs > 0 ->
    local_min xs 0 (length xs - 1) i ->
    is_local_min xs i.
Proof.
  intros xs i Hn Hlen Hmin.
  apply local_min_correct_induct in Hmin as Hpart; try lia; auto.
  unfold is_local_min_part in Hpart.
  unfold is_local_min.
  lia.
Qed.