From Coq Require Import Znumtheory Zdiv ZArith.

Section SimpleChineseRemainder .

Open Scope Z_scope .

Definition modulo (a b n : Z) : Prop := (n | (a - b)) .
Notation "( a === b [ n ])" := (modulo a b n). 

Lemma modulo_tran : forall a b c n : Z, 
    (a === b [ n ]) -> (b === c [ n ]) -> (a === c [ n ]) .
Proof .
  intros a b c n Hab Hbc .
  red in Hab, Hbc |- * .
  cut (a - c = a - b + (b - c)) .
  - intros H .
    rewrite H .
    apply Zdivide_plus_r .
    + trivial .
    + trivial .
  - auto with * .
Qed .

Lemma modulo_mult_subst : forall a b c n : Z,
    (a === b [ n ]) -> (a * c === b * c [ n ]) .
Proof .
  intros. unfold modulo. rewrite <-Z.mul_sub_distr_r. apply Z.divide_mul_l. auto.
Qed.

Hypothesis m n : Z .
Hypothesis co_prime : rel_prime m n .

Theorem modulo_inv : forall m n : Z, rel_prime m n ->
                       exists x : Z, (m * x === 1 [ n ]) .
Proof .
  intros m1 n1 Hrel.
  destruct (Znumtheory.rel_prime_bezout _ _ Hrel) .
  exists u.
  rewrite <- H. unfold modulo. 
  ring_simplify.  rewrite Z.mul_opp_l. rewrite  Z.divide_opp_r . 
  apply Z.divide_factor_l.
Qed.

Theorem SimpleChineseRemainder : forall a b : Z,
  exists x : Z, (x === a [ m ]) /\ (x === b [ n ]) .
Proof .
intros a b.
  destruct (modulo_inv m n co_prime) as [u Hu]. 
  set (x := m * u * (b - a) + a).
  exists x.
  split.
  - unfold modulo.
    subst x.
    ring_simplify.
    rewrite <-2!Z.mul_assoc. rewrite <-Z.mul_sub_distr_l.
    apply Z.divide_factor_l.
  - unfold modulo.
    subst x.
    ring_simplify.
    rewrite <-Z.sub_sub_distr. 
    rewrite <-Z.mul_sub_distr_l.
    unfold modulo in Hu.
    rewrite <-(Z.mul_1_l (b-a)) at 2. rewrite <-Z.mul_sub_distr_r.
    apply Z.divide_mul_l. apply Hu.
Qed.

End SimpleChineseRemainder .

