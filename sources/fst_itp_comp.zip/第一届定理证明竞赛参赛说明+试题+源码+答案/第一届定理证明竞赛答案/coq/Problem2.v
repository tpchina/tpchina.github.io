From Coq Require Import ZArith List.
Import ListNotations.
Local Open Scope Z.
Local Open Scope list.

(************)
(** 习题：  *)
(************)

(** 下面定义的_[prefixes]_函数计算了一个列表的所有前缀。*)

Fixpoint prefixes {A: Type} (l: list A): list (list A) :=
  match l with
  | nil => [nil]
  | a :: l0 => nil :: (map (cons a) (prefixes l0))
  end.

(** 例如：
   
        prefixes [1; 2]    = [ []     ;
                               [1]    ;
                               [1; 2] ] 
   
        prefixes [0; 1; 2] = [] ::
                             map (cons 0 (prefixes [1; 2]))
                           = [] ::
                             [ 0 :: []     ;
                               0 :: [1]    ;
                               0 :: [1; 2] ]
                           = [ []        ;
                               [0]       ;
                               [0; 1]    ;
                               [0; 1; 2] ]
      
    接下去，请分三步证明，_[prefixes l]_中的确实是_[l]_的全部前缀。*)

Lemma nil_in_prefixes:
  forall A (l: list A), In nil (prefixes l).
(* 请在此处填入你的证明，以_[Qed]_结束。 *)
Proof.
  intros.
  destruct l; simpl; tauto.
Qed.

Theorem in_prefixes:
  forall A (l1 l2: list A),
    In l1 (prefixes (l1 ++ l2)).
(* 请在此处填入你的证明，以_[Qed]_结束。 *)
Proof.
  intros.
  induction l1; simpl.
  + apply nil_in_prefixes.
  + right.
    apply in_map.
    tauto.
Qed.

Theorem in_prefixes_inv:
  forall A (l1 l: list A),
    In l1 (prefixes l) ->
    exists l2, l1 ++ l2 = l.
(* 请在此处填入你的证明，以_[Qed]_结束。 *)
Proof.
  intros.
  revert l1 H; induction l; simpl; intros.
  + destruct H as [? | []]; subst l1.
    exists nil; reflexivity.
  + destruct H.
    - subst l1.
      exists (a :: l).
      reflexivity.
    - apply in_map_iff in H.
      destruct H as [l1' [? ?]].
      apply IHl in H0.
      destruct H0 as [l2 ?].
      exists l2; subst l l1.
      reflexivity.
Qed.

(************)
(** 习题：  *)
(************)

(** 下面的_[sublists]_定义了列表中的所有连续段。*)

Fixpoint sublists {A: Type} (l: list A): list (list A) :=
  match l with
  | nil => [nil]
  | a :: l0 => map (cons a) (prefixes l0) ++ sublists l0
  end.

(** 请证明_[sublists l]_的元素确实是_[l]_中的所有连续段。提示：必要时可以添加并证明一
    些前置引理帮助完成证明。*)
Lemma nil_in_sublists:
  forall A (l: list A),
    In nil (sublists l).
Proof.
  intros.
  induction l; simpl.
  + tauto.
  + rewrite in_app_iff; tauto.
Qed.

Lemma prefixes_in_sublists:
  forall A (l1 l2: list A),
    In l1 (sublists (l1 ++ l2)).
Proof.
  intros.
  induction l1; simpl.
  + apply nil_in_sublists.
  + rewrite in_app_iff.
    left.
    apply in_map.
    apply in_prefixes.
Qed.

Theorem in_sublists:
  forall A (l1 l2 l3: list A),
    In l2 (sublists (l1 ++ l2 ++ l3)).
(* 请在此处填入你的证明，以_[Qed]_结束。 *)
Proof.
  intros.
  induction l1; simpl.
  + apply prefixes_in_sublists.
  + rewrite in_app_iff.
    tauto.
Qed.


Theorem in_sublists_inv:
  forall A (l2 l: list A),
    In l2 (sublists l) ->
    exists l1 l3, l1 ++ l2 ++ l3 = l.
Proof.
  intros.
  revert l2 H; induction l; simpl; intros.
  + destruct H as [? | []].
    subst l2; exists nil, nil; reflexivity.
  + rewrite in_app_iff in H.
    destruct H.
    - rewrite in_map_iff in H.
      destruct H as [l2' [? ?]].
      apply in_prefixes_inv in H0.
      destruct H0 as [l3 ?].
      exists nil, l3.
      subst l l2; reflexivity.
    - apply IHl in H.
      destruct H as [l1 [l3 ?]].
      exists (a :: l1), l3.
      subst l; reflexivity.
Qed.

