theory Problem6
  imports Main
begin

definition modulo :: "int \<Rightarrow> int \<Rightarrow> int \<Rightarrow> bool" where
  "modulo a b n \<equiv> n dvd (a - b)"

notation
  modulo ("(_ === _ [_] )" [30, 30] 50)

lemma modulo_trans:
  "a === b [n] \<Longrightarrow> b === c [n] \<Longrightarrow> a === c [n]"

  sorry

lemma modulo_mult_subst:
  "a === b [n] \<Longrightarrow> a * c === b * c [n]"

  sorry

lemma modulo_inv:
  assumes "coprime m n"
  shows "\<exists>x. m * x === 1 [n]"

  sorry

theorem simple_chinese_remainder:
  fixes a b m n :: int
  assumes "coprime m n"
  shows "\<exists>x. (x === a [m]) \<and> (x === b [n])"
  sorry

end
