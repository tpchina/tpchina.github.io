theory Problem2
  imports Main
begin

fun prefixes :: "'a list \<Rightarrow> 'a list list" where
  "prefixes [] = [[]]"
| "prefixes (a # l0) = [] # map (\<lambda>xs. a # xs) (prefixes l0)"

theorem in_prefixes: "l1 \<in> set (prefixes (l1 @ l2))"
  sorry

theorem in_prefixes_inv: 
  "l1 \<in> set (prefixes l) \<Longrightarrow> \<exists>l2. l1 @ l2 = l"
  sorry

fun sublists :: "'a list \<Rightarrow> 'a list list" where
  "sublists [] = [[]]"
| "sublists (a # l0) = map (\<lambda>xs. a # xs) (prefixes l0) @ sublists l0"

theorem in_sublists: "l2 \<in> set (sublists (l1 @ l2 @ l3))"
  sorry

theorem in_sublists_inv:
  "l2 \<in> set (sublists l) \<Longrightarrow> \<exists>l1 l3. l1 @ l2 @ l3 = l"
  sorry


end