theory Problem8
  imports Main "HOL-Hoare.HeapSyntax" (*"~~/src/HOL/Hoare/Hoare_Logic"*)
begin


abbreviation "K_NO_WAIT :: nat \<equiv> 0" 

(* alloc the first block in free_list *)
lemma mem_alloc01: "VARS free_list nxt slab mem timeout result
  {List nxt (slab^.free_list) Ps}
  IF slab^.free_list \<noteq> Null THEN
    mem := slab^.free_list;
    slab^.free_list := (slab^.free_list)^.nxt;
    result := 0
  ELSE 
    mem := Null;
    IF timeout = K_NO_WAIT THEN
      result := 1
    ELSE
      result := 2
    FI
  FI
  {(Ps \<noteq> [] \<longrightarrow> mem = Ref (hd Ps) \<and> result = 0 \<and> List nxt (slab^.free_list) (tl Ps)) \<and>
    (Ps = [] \<longrightarrow> mem = Null \<and> (result = 1 \<or> result = 2))}"
  apply vcg_simp
  apply fastforce done

(*declare [[show_types]]*)
record block = 
  block_size :: nat
  saddr :: nat

(* allocate the first block, which the block size \<ge> the requested size, in the free_list *)
lemma mem_alloc02: "VARS free_list next mem size result p q
  {distPath next free_list Ps Null}
    IF free_list = Null THEN
      mem := Null;
      result := 0
    ELSE
      IF block_size (addr free_list) \<ge> size THEN
        mem := free_list;
        free_list := free_list^.next;
        result := 1
      ELSE
        q := free_list;
        p := free_list^.next;
        WHILE p \<noteq> Null \<and> block_size (addr p) < size
        INV { True } \<comment> \<open> please define loop inv here \<close>
        DO 
          q := p;
          p := p^.next
        OD;
        IF p \<noteq> Null THEN
          mem := p;
          q^.next := p^.next;
          result := 1
        ELSE
          mem := Null;
          result := 0
        FI
      FI
    FI
  {(\<exists>a\<in>set Ps. block_size a \<ge> size) \<longrightarrow> 
      (let b = the (find (\<lambda>x. block_size x \<ge> size) Ps) in  
        mem = Ref b \<and> distPath next free_list (remove1 b Ps) Null) \<and> result = 1}"
  sorry

end