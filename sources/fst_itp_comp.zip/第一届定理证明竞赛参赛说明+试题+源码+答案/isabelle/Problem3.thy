theory Problem3
  imports Main
begin

datatype 'a tree =
  Leaf | Node 'a "'a tree" "'a tree"

fun mirror :: "'a tree \<Rightarrow> 'a tree" where
  "mirror Leaf = Leaf"
| "mirror (Node x l r) = Node x (mirror r) (mirror l)"

definition is_symmetric :: "'a tree \<Rightarrow> bool" where
  "is_symmetric t \<longleftrightarrow> (t = mirror t)"

fun check_mirror :: "'a tree \<Rightarrow> 'a tree \<Rightarrow> bool" where
  "check_mirror Leaf Leaf = True"
| "check_mirror (Node x1 l1 r1) (Node x2 l2 r2) =
   (x1 = x2 \<and> check_mirror l1 r2 \<and> check_mirror r1 l2)"
| "check_mirror Leaf (Node x l r) = False"
| "check_mirror (Node x l r) Leaf = False"

fun check_symmetric :: "'a tree \<Rightarrow> bool" where
  "check_symmetric Leaf = True"
| "check_symmetric (Node x l r) = check_mirror l r"

lemma check_mirror_correct [simp]:
  "check_mirror t1 t2 \<longleftrightarrow> (t1 = mirror t2)"
  sorry


theorem check_symmetric_correct:
  "check_symmetric t = is_symmetric t"
  sorry