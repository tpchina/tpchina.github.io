theory Problem1
  imports Main
begin

consts
  P :: "nat \<Rightarrow> bool"
  Q :: "nat \<Rightarrow> bool" 
  R :: "nat \<Rightarrow> nat \<Rightarrow> bool"

inductive A :: "nat \<Rightarrow> bool" and B :: "nat \<Rightarrow> bool" where
  ca0: "P n \<Longrightarrow> A n"
| ca1: "(\<forall>n2. R n1 n2 \<longrightarrow> B n2) \<Longrightarrow> A n1"
| cb0: "Q n \<Longrightarrow> B n"  
| cb1: "R n1 n2 \<Longrightarrow> A n2 \<Longrightarrow> B n1"

thm "A_B.inducts"

theorem neg_a:
  assumes "\<forall>n. \<not> P n \<and> \<not> Q n"
      and "\<forall>n1. \<exists>n2. R n1 n2"
    shows "\<forall>n. \<not> A n"
  sorry

end