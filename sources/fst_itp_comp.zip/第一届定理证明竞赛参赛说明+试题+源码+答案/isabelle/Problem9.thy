theory Problem9
  imports "HOL-Library.Monad_Syntax"
begin

section \<open>tick monad\<close>
type_synonym 'a tick_monad = "unit \<Rightarrow> 'a \<times> nat"

definition
  return :: "'a \<Rightarrow> 'a tick_monad" where
  "return a \<equiv> \<lambda>_. (a, 0)"

definition
  bind :: "'a tick_monad \<Rightarrow> ('a \<Rightarrow> 'b tick_monad) \<Rightarrow> 'b tick_monad"
  where
  "bind f g \<equiv> (\<lambda>_. (let (r1,t1) = f () in
                    let (r2,t2) = g r1 () in (r2, t1 + t2)))"

definition tick :: "nat \<Rightarrow> (unit) tick_monad"
  where "tick n \<equiv> \<lambda>_. ((), n)"

adhoc_overloading
  Monad_Syntax.bind \<rightleftharpoons> Problem9.bind (* Isabelle 2025 works *)
  (* Monad_Syntax.bind Tick_Monad.bind *) (* Isabelle 2023, 2024 works*)


section \<open>Queue\<close>

record 'a Queue = inq :: "'a list"
                  outq :: "'a list"

abbreviation "mk a b \<equiv> \<lparr>inq = a, outq = b\<rparr>"

definition empty :: "('a Queue) tick_monad"
  where "empty \<equiv> return (mk [] [])"

primrec aux :: "'a list \<Rightarrow> 'a list \<Rightarrow> ('a list) tick_monad"
  where "aux [] l = return l" |
        "aux (a#t) l = do { tick 1; aux t (a # l) }" 

definition in_to_out :: "'a Queue \<Rightarrow> ('a Queue) tick_monad"
  where "in_to_out q \<equiv> do { r \<leftarrow> aux (inq q) (outq q); return (mk [] r)}"

definition enq :: "'a Queue \<Rightarrow> 'a \<Rightarrow> ('a Queue) tick_monad"
  where "enq q x \<equiv> do {tick 1; return (mk (x#(inq q)) (outq q))}"

definition deq :: "'a Queue \<Rightarrow> ('a option \<times> 'a Queue) tick_monad"
  where "deq q \<equiv> do {
                       tick 1; 
                       case (outq q) of (h#t) \<Rightarrow> return (Some h, mk (inq q) t) |
                                        [] \<Rightarrow> do { p \<leftarrow> in_to_out q;
                                                   case (outq p) of [] \<Rightarrow> return (None, p) |
                                                                    (h#t) \<Rightarrow> return (Some h, mk (inq p) t)
                                                 }
                     }"


primrec seq_op_queue :: "'a Queue \<Rightarrow> ('a option) list \<Rightarrow> ('a Queue) tick_monad"
  where "seq_op_queue q [] = return q" |
        "seq_op_queue q (op#ops') = (case op of Some x \<Rightarrow> do {q' \<leftarrow> enq q x; seq_op_queue q' ops'} |
                                                None \<Rightarrow> do {(_,q') \<leftarrow> deq q; seq_op_queue q' ops'})"


definition seq_op_queue_from_empty :: "('a option) list \<Rightarrow> ('a Queue) tick_monad"
  where "seq_op_queue_from_empty ops \<equiv> do {q \<leftarrow> empty; seq_op_queue q ops}"


section \<open>Proof\<close>

theorem seq_op_queue_from_empty_cost : "snd (seq_op_queue_from_empty ops ()) \<le> 2 * (length ops)"
  sorry

end
