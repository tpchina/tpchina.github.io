theory Problem7
imports
  Main
begin

definition xorb :: "bool => bool => bool" where
"xorb b1 b2 = (if b1 then if b2 then False else True else b2)"

definition b2z :: "bool => int" where
"b2z b = (if b then 1 else 0)"

lemma b2z_div2 : "b2z b div 2 = 0" using b2z_def by auto

lemma odd_sub : "odd (n - m) = xorb (odd (n::int)) (odd m)"
  using xorb_def
  by simp

lemma Zodd_b2z : "odd (b2z b) = b" using b2z_def by auto


lemma b2z_exist: "\<exists> cr. b2z cr = b2z (Not (odd x) \<and> odd y) + b2z (Not (xorb (odd x) (odd y)) \<and> c0)"
  sorry

axiomatization
  sub_borrow_bit :: "int \<Rightarrow> int \<Rightarrow> bool \<Rightarrow> nat \<Rightarrow> bool"

(** using the following definition

fun sub_borrow_bit :: "int \<Rightarrow> int \<Rightarrow> bool \<Rightarrow> nat \<Rightarrow> bool" where
"sub_borrow_bit _ _ c 0 = c" |
"sub_borrow_bit x y c (Suc n) = (
  let pc = sub_borrow_bit x y c n in
  xxx
)" *)

lemma sub_shift : "(a - b) div 2 = a div 2 - b div 2 - b2z (Not (odd a) \<and> odd b)"
  sorry


lemma sub_borrow_bit_eq:
"b2z (Not (odd x) \<and> odd y) + b2z (Not (xorb (odd x) (odd y)) \<and> c0) = b2z cr \<Longrightarrow>
sub_borrow_bit (x div 2) (y div 2) cr n =
(Not (bit x n) \<and> bit y n) \<or> (sub_borrow_bit x y c0 n \<and> Not (xorb (bit x n) (bit y n)))"
  sorry                                                                                                          

lemma xtestbit_sub_sound:
  "bit (x - y - b2z c) n =
      xorb (xorb (bit x n)
              (bit y n)) (sub_borrow_bit x y c n)"
  sorry


lemma ztestbit_sub_sound:
  "bit (x - y) n =
      xorb (xorb (bit x n)
              (bit y n)) (sub_borrow_bit x y False n)"
  apply (subgoal_tac "x - y - b2z False = x - y")
  prefer 2 subgoal using b2z_def by simp
  using xtestbit_sub_sound by metis

end