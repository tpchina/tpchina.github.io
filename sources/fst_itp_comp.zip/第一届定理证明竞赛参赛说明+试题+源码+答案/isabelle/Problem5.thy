theory Problem5
  imports Main
begin


consts
  C :: nat
  N :: nat
  caps :: "nat \<Rightarrow> nat"
  vals :: "nat \<Rightarrow> nat"

axiomatization where posN: "N > 0"


definition clear :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> bool option" where
  "clear s i j = (if j = i then None else s j)"

fun val_in_knapsack :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> nat option" where
  "val_in_knapsack s 0 c_rem = Some 0"
| "val_in_knapsack s (Suc n') c_rem = (
    let s' = clear s (Suc n') in
    case s (Suc n') of
      Some True \<Rightarrow> 
        if caps (Suc n') \<le> c_rem then
          (case val_in_knapsack s' n' (c_rem - caps (Suc n')) of
            Some v \<Rightarrow> Some (v + vals (Suc n'))
          | None \<Rightarrow> None)
        else None
    | Some False \<Rightarrow> val_in_knapsack s' n' c_rem
    | None \<Rightarrow> None)"

definition wf :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> bool" where
  "wf s n \<equiv> \<forall>i. (s i \<noteq> None) \<longleftrightarrow> (1 \<le> i \<and> i \<le> n)"

definition opt_s :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> bool" where
  "opt_s s n c_rem \<equiv> 
    wf s n \<and> 
    (\<forall>s' v1 v2. 
      wf s' n \<longrightarrow> 
      val_in_knapsack s' n c_rem = Some v1 \<longrightarrow> 
      val_in_knapsack s n c_rem = Some v2 \<longrightarrow> 
      v1 \<le> v2)"

lemma wf_clr: "1 \<le> n \<Longrightarrow> n \<le> N \<Longrightarrow> wf s n \<Longrightarrow> wf (clear s n) (n - 1)"
  sorry

definition set_s :: "(nat \<Rightarrow> bool option) \<Rightarrow> nat \<Rightarrow> bool \<Rightarrow> nat \<Rightarrow> bool option" where
  "set_s s i b j = (if j = i then Some b else s j)"

lemma wf_set_s: "
      1 \<le> n \<Longrightarrow> 
      wf s (n - 1) \<Longrightarrow>
      wf (set_s s n b) n"
  sorry

lemma clr_set: "
      s n = None \<Longrightarrow>
      clear (\<lambda> j. if j = n then Some True else s j) n = s"
  sorry

theorem optimal_substructure: "
      1 \<le> n \<Longrightarrow> n \<le> N \<Longrightarrow>
      s n = Some True \<Longrightarrow>
      caps n <= c_rem \<Longrightarrow>
      opt_s s n c_rem \<Longrightarrow>
      opt_s (clear s n) (n - 1) (c_rem - caps n)"
 sorry

end