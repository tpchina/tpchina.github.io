theory Problem4
  imports Main
begin

section \<open>Finding local minimum\<close>

definition neighbor_nonequal :: "nat list \<Rightarrow> bool" where
  "neighbor_nonequal xs = (\<forall>i. i < length xs - 1 \<longrightarrow> xs ! i \<noteq> xs ! (i + 1))"

definition is_local_min :: "nat list \<Rightarrow> nat \<Rightarrow> bool" where
  "is_local_min xs i =
  (i \<ge> 0 \<and> i < length xs \<and>
   (i = 0 \<or> xs ! i < xs ! (i - 1)) \<and>
   (i = length xs - 1 \<or> xs ! i < xs ! (i + 1)))"

function local_min :: "nat list \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> nat" where
  "local_min xs left right =
    (if left \<ge> right then left
     else if left + 1 = right then
        if xs ! left < xs ! right then left else right
     else let mid = (left + right) div 2 in
       if xs ! (mid - 1) < xs ! mid then
         local_min xs left (mid - 1)
       else
         local_min xs mid right)"
  by pat_completeness auto
termination by (relation "measure (\<lambda>(xs,l,r). r - l)", auto)
declare local_min.simps [simp del]

definition is_local_min_part :: "nat list \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> nat \<Rightarrow> bool" where
  "is_local_min_part ls i l r =
   (i \<ge> l \<and> i \<le> r \<and>
    (i = 0 \<or> ls ! i < ls ! (i - 1)) \<and>
    (i = length ls - 1 \<or> ls ! i < ls ! (i + 1)))"

thm  "local_min.induct"

lemma local_min_correct_induct:
  "neighbor_nonequal xs \<Longrightarrow> 0 \<le> a \<Longrightarrow> a \<le> b \<Longrightarrow> b < length xs \<Longrightarrow>
   a = 0 \<or> xs ! a < xs ! (a - 1) \<Longrightarrow>
   b = length xs - 1 \<or> xs ! b < xs ! (b + 1) \<Longrightarrow>
   is_local_min_part xs (local_min xs a b) a b"
proof (induction rule: local_min.induct)
  case (1 xs left right)
  show ?case
  proof (cases "left \<ge> right")
    case True
    then show ?thesis
      sorry
  next
    case False
    note False1 = False
    then show ?thesis
    proof (cases "left + 1 = right")
      case True
      then show ?thesis
        sorry
    next
      case False
      note False2 = False
      let ?mid = "(left + right) div 2"
      show ?thesis
      proof (cases "xs ! (?mid - 1) < xs ! ?mid")
        case True
        show ?thesis
          sorry 
      next
        case False
        show ?thesis
          sorry
        qed
    qed
  qed
qed

theorem local_min_correct:
  assumes "neighbor_nonequal xs"
  assumes "length xs > 0"
  shows "is_local_min xs (local_min xs 0 (length xs - 1))"
  sorry



end
