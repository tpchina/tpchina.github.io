import Mathlib.Data.Int.Bitwise

axiom Z.bit0_odd : forall (a : ℤ), Int.testBit a 0 = Int.bodd a

axiom Z_div_mod_eq_full
     : forall a b : ℤ, a = b * (a / b) + a % b
axiom Zodd_mod
     : forall a : ℤ, Int.bodd a = ((a % 2) == 1)

axiom Z.bit0_mod
     : forall a : ℤ, Bool.toInt (Int.testBit a 0) = a % 2

axiom Z.testbit_succ_r
     : forall (a : ℤ) (b : Bool) (n : Nat),
0 <= n -> Int.testBit (2 * a + Bool.toInt b) (n.succ) = Int.testBit a n

axiom Z.odd_sub
     : forall n m : ℤ, Int.bodd (n - m) = xor (Int.bodd n) (Int.bodd m)

lemma Zodd_b2z : ∀ (b : Bool), Int.bodd (Bool.toInt b) = b := by
  intro b
  cases b <;> rfl


lemma decomp : ∀ (x : ℤ), x = 2 * (x / 2) + Bool.toInt (Int.bodd x) :=
by
  intro x
  rw [<- Z.bit0_odd]
  rw [Z.bit0_mod]
  apply Z_div_mod_eq_full

lemma b2z_div2 : ∀ (b : Bool), (Bool.toInt b / 2 : ℤ) = 0 := by
  intro b
  cases b <;> rfl

lemma b2z_exists : ∀ (x y : ℤ) (c0 : Bool),
  ∃ (cr : Bool),
    Bool.toInt ((not (Int.bodd x)) && Int.bodd y) +
    Bool.toInt ((not (xor (Int.bodd x) (Int.bodd y))) && c0) = Bool.toInt cr := by
  sorry

axiom sub_borrow_bit (x y : ℤ) (c : Bool) : ℕ → Bool
-- 请替换 sub_borrow_bit 为下列代码
-- def sub_borrow_bit (x y : ℤ) (c : Bool) : ℕ → Bool
--   | 0 => c
--   | n + 1 =>
--     let pc := sub_borrow_bit x y c n
--     xxx


lemma sub_shift : ∀ a b : ℤ,
    ((a - b) / 2) = (a / 2 - b / 2 - Bool.toInt ((not (Int.bodd a)) && Int.bodd b)) := by
  sorry

lemma sub_borrow_bit_eq : ∀ (n : ℕ) (x y : ℤ) (cr c0 : Bool)
  (_ :
    Bool.toInt ((not (Int.bodd x)) && Int.bodd y) +
    Bool.toInt ((not (xor (Int.bodd x) (Int.bodd y))) && c0) =
      Bool.toInt cr),
    sub_borrow_bit (x / 2) (y / 2) cr n =
    (((not (x.testBit n)) && y.testBit n) ||
    (sub_borrow_bit x y c0 n && (not (xor (x.testBit n) (y.testBit n))))) := by
  sorry

lemma xtestbit_sub_sound : ∀ (n : ℕ) (x y : ℤ) (c0 : Bool),
    ((x - y - Bool.toInt c0).testBit n) =
    xor (xor (x.testBit n) (y.testBit n)) (sub_borrow_bit x y c0 n) :=
by
  sorry


lemma testbit_sub_sound : ∀ (n : ℕ) (x y : ℤ),
    ((x - y).testBit n) = xor (xor (x.testBit n) (y.testBit n)) (sub_borrow_bit x y false n) := by
  intro n x y
  rw [show (x - y) = (x - y - Bool.toInt false) by simp [Bool.toInt]]
  exact xtestbit_sub_sound n x y false
