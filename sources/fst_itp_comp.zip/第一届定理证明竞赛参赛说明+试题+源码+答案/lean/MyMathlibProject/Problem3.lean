
inductive Tree (A : Type) : Type where
  | leaf : Tree A
  | node : A → Tree A → Tree A → Tree A

def mirror {A : Type} : Tree A → Tree A
  | Tree.leaf => Tree.leaf
  | Tree.node x l r => Tree.node x (mirror r) (mirror l)

def is_symmetric {A : Type} (t : Tree A) : Prop :=
  t = mirror t

def check_mirror {A : Type} : Tree A → Tree A → Prop
  | Tree.leaf, Tree.leaf => True
  | Tree.node x1 l1 r1, Tree.node x2 l2 r2 =>
      (x1 = x2) ∧ check_mirror l1 r2 ∧ check_mirror r1 l2
  | _, _ => False

def check_symmetric {A : Type} : Tree A → Prop
  | Tree.leaf => True
  | Tree.node _ l r => check_mirror l r

theorem check_mirror_correct {A : Type} (t1 t2 : Tree A) :
    check_mirror t1 t2 ↔ t1 = mirror t2 := by
  sorry


theorem check_symmetric_correct {A : Type} (t : Tree A) :
    check_symmetric t ↔ is_symmetric t := by
  sorry
