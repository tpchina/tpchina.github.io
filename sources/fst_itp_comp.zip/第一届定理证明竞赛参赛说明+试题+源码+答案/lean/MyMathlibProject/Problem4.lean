import Mathlib.Data.Nat.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic

def neighbor_nonequal (xs : List Nat) : Bool :=
  ∀ i, i < xs.length - 1 → xs.getD i 0 ≠ xs.getD (i + 1) 0

def is_local_min (xs : List Nat) (i : Nat) : Prop :=
  i < xs.length ∧
  (i = 0 ∨ xs.getD i 0 < xs.getD (i - 1) 0) ∧
  (i = xs.length - 1 ∨ xs.getD i 0 < xs.getD (i + 1) 0)

lemma ge_exists (right left : ℕ) (g : right > left) (n : left + 1 ≠ right) :
    ∃ n0 : ℕ, right = n0 + left ∧ n0 > 1 := by
  induction right generalizing left with
  | zero =>
    exfalso; linarith [g]
  | succ k IH =>
    rcases left with (_ | m)
    · refine ⟨k + 1, ?_, by omega⟩
      omega
    · have g' : k > m := by omega
      have n' : m + 1 ≠ k := by
        intro h
        apply n
        omega
      rcases IH m g' n' with ⟨k', hk1, hk2⟩
      refine ⟨k', ?_, hk2⟩
      omega

lemma div2_plus_2 : ∀ k, (k + 2) / 2 = k / 2 + 1 := by
  intros k
  simp

lemma div2_plus_2n : ∀ n k,  (k + (n + n)) / 2 =  k / 2 + n := by
  intro n
  omega

lemma div2_le : ∀ n k, n ≤ k → n / 2 ≤ k /2 := by
  intro n k h
  omega

inductive local_min : List Nat → Nat → Nat → Nat → Prop
  | case_le_right_left (xs : List Nat) (l r : Nat) (h : r ≤ l) : local_min xs l r l
  | case_left_plus_1_eq_right_l (xs : List Nat) (l r : Nat) (h : l < r) (h1 : r = l + 1)
      (h2 : xs.getD l 0 < xs.getD r 0) : local_min xs l r l
  | case_left_plus_1_eq_right_r (xs : List Nat) (l r : Nat) (h : l < r) (h1 : r = l + 1)
      (h2 : xs.getD r 0 ≤ xs.getD l 0) : local_min xs l r r
  | case_mid_1 (xs : List Nat) (l r mid i : Nat)
    (h : l < r) (h1 : l + 1 ≠ r) (h2 : mid = (l + r) / 2)
      (h3 : xs.getD (mid - 1) 0 < xs.getD mid 0)
      (h4 : local_min xs l (mid - 1) i) : local_min xs l r i
  | case_mid_r (xs : List Nat) (l r mid i : Nat)
    (h : l < r) (h1 : l + 1 ≠ r) (h2 : mid = (l + r) / 2)
      (h3 : xs.getD mid 0 ≤ xs.getD (mid - 1) 0)
      (h4 : local_min xs mid r i) : local_min xs l r i

def is_local_min_part (ls : List Nat) (l r i : Nat) : Prop :=
  i ≥ l ∧ i ≤ r ∧
  (i = 0 ∨ (i < ls.length ∧ (i - 1) < ls.length ∧ ls.getD i 0 < ls.getD (i - 1) 0)) ∧
  (i = ls.length - 1 ∨ (i < ls.length ∧ (i + 1) < ls.length ∧ ls.getD i 0 < ls.getD (i + 1) 0))

lemma local_min_correct_induct (xs : List Nat) (a b i : Nat)
    (H_neighbor : neighbor_nonequal xs) (H_a_lower : 0 ≤ a)
    (H_ab : a ≤ b) (H_b_upper : b < xs.length)
    (H_a_cond : a = 0 ∨ (a < xs.length ∧ (a - 1) < xs.length ∧ xs.getD a 0 < xs.getD (a - 1) 0))
    (H_b_cond : b = xs.length - 1 ∨
            (b < xs.length ∧ (b + 1) < xs.length ∧ xs.getD b 0 < xs.getD (b + 1) 0))
    (Hi : local_min xs a b i) : is_local_min_part xs a b i := by
  unfold is_local_min_part
  induction Hi with
  | case_le_right_left l r h =>
    have heq : l = r := by omega
    subst l
    omega

  | case_left_plus_1_eq_right_l l r h h1 h2 =>
    sorry
  | case_left_plus_1_eq_right_r l r H H1 H2 =>
    sorry
  | case_mid_1 l r mid i H H1 H2 H3 H4 H4_ih =>
    sorry

  | case_mid_r l r mid res H H1 H2 H3 H4 H4_ih =>
    sorry

theorem local_min_correct (xs : List Nat) (i : Nat)
    (Hn : neighbor_nonequal xs) (Hlen : xs.length > 0)
    (Hmin : local_min xs 0 (xs.length - 1) i) : is_local_min xs i := by
  sorry
