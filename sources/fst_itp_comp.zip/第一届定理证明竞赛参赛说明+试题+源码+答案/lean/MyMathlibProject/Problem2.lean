import Mathlib.Data.Int.Bitwise

def prefixes {A : Type} : List A → List (List A)
  | [] => [[]]
  | a :: l0 => [] :: (List.map (fun x => a :: x) (prefixes l0))

theorem in_prefixes {A : Type} (l1 l2 : List A) : l1 ∈ prefixes (l1 ++ l2) := by
  sorry

theorem in_prefixes_inv {A : Type} (l1 l : List A) :
    l1 ∈ prefixes l → ∃ l2, l1 ++ l2 = l := by
  sorry

def sublists {A : Type} : List A → List (List A)
  | [] => [[]]
  | a :: l0 => List.map (fun x => a :: x) (prefixes l0) ++ sublists l0


theorem in_sublists {A : Type} (l1 l2 l3 : List A) :
    l2 ∈ sublists (l1 ++ l2 ++ l3) := by
  sorry

theorem in_sublists_inv {A : Type} (l2 l : List A) :
    l2 ∈ sublists l → ∃ l1 l3, l1 ++ l2 ++ l3 = l := by
  sorry
