import Auto

import Loom.MonadAlgebras.NonDetT.Extract
import Loom.MonadAlgebras.WP.Tactic
import Loom.MonadAlgebras.WP.DoNames'

import CaseStudies.Velvet.Std
import CaseStudies.TestingUtil

open PartialCorrectness DemonicChoice Lean.Elab.Term.DoNames

@[reducible]
def addr := ℤ

@[reducible]
def path (h : addr → addr) (x : addr) (l : List addr) (y : addr) :=
  match l with
  | [] => x = y
  | a :: t => a ≠ 0 ∧ x = a ∧ path h (h a) t y

@[reducible]
def distinct (l : List addr) :=
  match l with
  | [] => ⊤
  | a :: t => (∀ x, x ∈ t → x ≠ a) ∧ distinct t

@[reducible]
def distPath (h : addr → addr) (x : addr) (l : List addr) (y : addr) :=
  path h x l y ∧ distinct l

method mem_alloc
  (saddr : addr → addr) (block_size : addr → ℕ) (mut next : addr → addr)
  (mut free_list : addr) (size : ℕ)
  (Ps : List addr)
return (mem : addr)
  require distPath next free_list Ps 0
  ensures ∀ b, List.find? (fun x => block_size x ≥ size) Ps = some b →
          mem = b ∧ distPath next free_list (List.erase Ps b) 0
do
  if free_list = 0 then
    return 0
  else
    if block_size free_list ≥ size then
      let res := free_list
      free_list := next free_list
      return res
    else
      let mut q := free_list
      let mut p := next free_list
      while p ≠ 0 ∧ block_size p < size
      invariant distPath next free_list Ps 0
      invariant ∃ Qs, distPath next free_list Qs p ∧ ∀ a, a ∈ Qs → block_size a < size
      invariant p = next q
      invariant ∃ Qs, distPath next free_list Qs q
      invariant q ≠ 0
      do
        q := p
        p := next p
      if p ≠ 0 then
        next := Function.update next q (next p)
        return p
      else
        return 0

prove_correct mem_alloc by
  sorry
