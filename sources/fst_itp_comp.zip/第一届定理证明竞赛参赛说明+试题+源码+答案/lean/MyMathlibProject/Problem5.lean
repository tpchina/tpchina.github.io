import Mathlib.Data.Real.Basic

section ProblemB
variable (C : ℕ)
variable (N : ℕ)
variable (posN : N > 0)
variable (caps : ℕ → ℕ)
variable (vals : ℕ → ℕ)

def clear (s : ℕ → Option Bool) (i : ℕ) : ℕ → Option Bool :=
  fun j => if j = i then none else s j

def val_in_knapsack (s : ℕ → Option Bool) (n : ℕ) (c_rem : ℕ) : Option ℕ :=
  match n with
  | 0 => some 0
  | n' + 1 =>
    let s' := clear s n;
    match s n with
    | some true =>
      if caps n ≤ c_rem then
        match val_in_knapsack s' n' (c_rem - caps n) with
        | some v => some (v + vals n)
        | _ => none
      else
        none
    | some false =>
        val_in_knapsack s' n' c_rem
    | none => none

def wf (s : ℕ → Option Bool) (n : ℕ) : Prop :=
  ∀ i, (s i ≠ none ↔ 1 ≤ i ∧ i ≤ n)

def opt_s (s : ℕ → Option Bool) (n c_rem : ℕ) : Prop :=
  wf s n ∧
  ∀ (s' : ℕ → Option Bool) (v1 v2 : ℕ),
    wf s' n →
    val_in_knapsack caps vals  s' n c_rem = some v1 →
    val_in_knapsack caps vals  s n c_rem = some v2 →
      v1 ≤ v2

lemma wf_clr (s : ℕ → Option Bool) (n : ℕ)
    (Hlt : 1 ≤ n ∧ n ≤ N) (Hwf : wf s n) : wf (clear s n) (n - 1) :=
by
  sorry

def set_s (s : ℕ → Option Bool) (i : ℕ) (b : Bool) : ℕ → Option Bool :=
  fun j => if j = i then some b else s j

lemma wf_set_s (s : ℕ → Option Bool) (n : ℕ) (b : Bool)
    (Hge : 1 ≤ n) (Hwf : wf s (n - 1)) : wf (set_s s n b) n := by
  sorry

lemma clr_set (s : ℕ → Option Bool) (n : ℕ)
    (Hn : s n = none) : clear (fun j => if j = n then some true else s j) n = s := by
  sorry

-- #check opt_s
-- #check opt_s
-- #check wf_clr
-- #check Nat.exists_eq_succ_of_ne_zero
theorem optimal_substructure (s : ℕ → Option Bool) (n c_rem : ℕ)
    (Hrgn : 1 ≤ n ∧ n ≤ N) (Htt : s n = some true) (Hrem : caps n ≤ c_rem)
    (Hopt : opt_s caps vals s n c_rem) : opt_s caps vals (clear s n) (n - 1) (c_rem - caps n) := by
  sorry
end ProblemB
