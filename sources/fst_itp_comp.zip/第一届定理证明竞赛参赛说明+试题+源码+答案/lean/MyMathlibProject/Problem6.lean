import Init.Data.Int
import Mathlib.Data.Int.GCD
abbrev Z := Int

def modulo (n a b : Z) : Prop := n ∣ (a - b)
notation " ( " a " ≡ " b " mod " n  " ) "=> modulo n a b

def modulo_tran : ∀ (a b c n : Z),
  (a ≡ b mod n) -> (b ≡ c mod n) -> (a ≡ c mod n)
:= by
sorry

instance {n} : Trans (modulo n) (modulo n) (modulo n) where
  trans {a} {b} {c} := modulo_tran a b c n


def modulo_mult_subst : ∀ (a b c n : Z),
  (a ≡ b mod n) -> (a * c ≡ b * c mod n)
:= by
  sorry


abbrev rel_prime m n := Int.gcd m n = 1

theorem modulo_inv : ∀ (m n : Z), rel_prime m n -> ∃ x : Z, (m * x ≡ 1 mod n)
:= by
  sorry


theorem SimpleChineseRemainder :
  ∀ m n : Z, rel_prime m n ->
  ∀ a b : Z, ∃ x : Z, (x ≡ a mod m) ∧ (x ≡ b mod n)
:= by
  sorry
