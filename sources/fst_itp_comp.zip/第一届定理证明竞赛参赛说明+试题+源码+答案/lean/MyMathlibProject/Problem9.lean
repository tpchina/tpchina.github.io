import Mathlib.Tactic

def Tick (α : Type) : Type := Unit → α × Nat

instance : Monad Tick where
  pure r := fun _ => (r, 0)
  bind f g := fun _ =>
    let (r1, c1) := f ()
    let (r2, c2) := g r1 ()
    (r2, c1 + c2)

def tick (c : Nat) : Tick Unit := fun _ => ((), c)

structure Queue (α : Type) where
  inq : List α
  outq : List α

def Queue.empty (α : Type) : Tick (Queue α) := pure (mk [] [])

def Queue.in_to_out {α : Type} (q : Queue α) : Tick (Queue α) :=
  let rec aux (l1 l2 : List α) : Tick (List α) :=
    match l1 with
    | [] => pure l2
    | h :: t =>
      tick 1 >>= fun _ =>
      aux t (h :: l2)
  aux q.inq q.outq >>= fun r =>
  pure (mk [] r)

def Queue.enq {α : Type} (q : Queue α) (x : α) : Tick (Queue α) :=
  tick 1 >>= fun _ =>
  pure (mk (x :: q.inq) q.outq)

def Queue.deq {α : Type} (q : Queue α) : Tick (Option α × Queue α) :=
  tick 1 >>= fun _ =>
  match q.outq with
  | h :: t => pure (some h, mk q.inq t)
  | [] =>
    q.in_to_out >>= fun q' =>
    match q'.outq with
    | [] => pure (none, q')
    | h :: t => pure (some h, mk q'.inq t)

def seq_op_queue {α : Type} (q : Queue α) (ops : List (Option α)) : Tick (Queue α) :=
  match ops with
  | [] => pure q
  | op :: ops' =>
    match op with
    | some x =>
      q.enq x >>= fun q' =>
      seq_op_queue q' ops'
    | none =>
      q.deq >>= fun (_, q') =>
      seq_op_queue q' ops'

def seq_op_queue_from_empty {α : Type} (ops : List (Option α)) : Tick (Queue α) :=
  Queue.empty α >>= fun q =>
  seq_op_queue q ops


theorem seq_op_queue_from_empty_cost {α : Type} (ops : List (Option α)) :
  (seq_op_queue_from_empty ops ()).2 ≤ 2 * ops.length
:= sorry
